-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 04, 2021 at 06:54 PM
-- Server version: 10.2.36-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `honore_paymatic`
--

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

CREATE TABLE `certificates` (
  `plate` varchar(100) NOT NULL,
  `owner` varchar(100) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `startdate` date NOT NULL,
  `endingdate` date NOT NULL,
  `sms` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `certificates`
--

INSERT INTO `certificates` (`plate`, `owner`, `telephone`, `startdate`, `endingdate`, `sms`) VALUES
('RA8459X', 'Manzi Tresor', '250788242412', '2020-01-22', '2020-01-24', 1),
('RAA456T', 'RITCO', '250788242412', '2020-01-22', '2020-01-25', 1),
('RAB100K', 'Maurice', '250788242412', '2020-01-17', '2020-01-18', 1),
('RAB459X', 'MOMO', '250788242412', '2020-01-18', '2020-01-26', 1),
('RAD123X', 'BLONDI', '250789407131', '2020-02-26', '2020-03-01', 1),
('RAD123Y', 'PETER', '25078862750', '2020-03-13', '2020-03-21', 0),
('RAD231T', 'AUTY', '250788337540', '2020-01-22', '2020-01-23', 1),
('Rad234', 'me', '250788242412', '2020-01-21', '2020-01-23', 1),
('RAD459P', 'MOMO', '250788242412', '2020-01-23', '2020-01-25', 1),
('RAD459X', 'ROYAL', '250788242412', '2020-01-17', '2020-01-23', 1),
('RAE123X', 'Manzi Tresor', '250788242412', '2020-01-07', '2020-01-19', 1),
('RAE134X', 'RITCO', '250788242412', '2020-01-16', '2020-01-17', 1),
('RAE270G', 'MIKE', '250783105504', '2020-01-28', '2020-01-30', 1),
('RAE459X', 'Manzi Tresor', '250788444316', '2020-01-18', '2020-01-25', 1),
('RAF356C', 'Manzi Tresor', '250788242412', '2020-01-10', '2020-02-07', 1),
('RAF43DV', 'Manzi Tresor', '250788242412', '2020-01-16', '2020-01-17', 1),
('RAFfyhj', 'RITCO', '250788242412', '2020-01-15', '2020-01-15', 1),
('RAg459X', 'Manzi Tresor', '250788242412', '2020-01-22', '2020-01-24', 1),
('RAH201K', 'Manzi Tresor', '250788242412', '2020-01-18', '2020-01-24', 1),
('RAO231T', 'AUTY', '250788242412', '2020-01-23', '2020-01-24', 1),
('RAO459X', 'Manzi Tresor', '250788242412', '2020-01-15', '2020-01-16', 1),
('RAP459X', 'RITCO', '250788242412', '2020-01-16', '2020-01-17', 1),
('RAQ1234X', 'Manzi Tresor', '250788242412', '2020-01-10', '2020-01-16', 1),
('RAS459X', 'MOMO', '250788444316', '2020-01-14', '2020-01-15', 1),
('RAT123X', 'ROYAL', '250788242412', '2020-02-04', '2020-02-06', 1),
('RAT459X', 'RITCO', '250788242412', '2020-01-16', '2020-01-17', 1),
('RAT563C', 'Manzi Tresor', '250725911912', '2020-01-17', '2020-01-17', 1),
('RAU123X', 'RITCO', '250788242412', '2020-01-16', '2020-01-24', 1),
('RAW125X', 'MOMO', '250788242412', '2020-01-15', '2020-01-23', 1),
('RAW459X', 'RITCO', '250788242412', '2020-01-17', '2020-01-25', 1),
('RAY459X', 'Manzi Tresor', '250788242412', '2020-01-25', '2020-01-27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id_card` varchar(16) NOT NULL,
  `names` varchar(25) NOT NULL,
  `district` varchar(25) NOT NULL,
  `sector` varchar(25) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(250) NOT NULL,
  `joinedon` varchar(50) NOT NULL,
  `admin` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id_card`, `names`, `district`, `sector`, `phone`, `username`, `password`, `joinedon`, `admin`) VALUES
('123', 'Maurice', 'musanze', '', '0788466520', 'Maurice', '123', '12/06/2019', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` varchar(10) NOT NULL,
  `stock` varchar(50) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `stock`) VALUES
(6, 'Speed Governor', '285000', '390'),
(7, 'GPS', '60000', '940');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`plate`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id_card`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
