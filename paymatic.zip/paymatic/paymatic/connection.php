<?php
	$db_con = mysqli_connect('localhost','root','','paymatic');
	
	
?>