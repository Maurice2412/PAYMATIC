	<!DOCTYPE html>
<html>
<head>
	<title>Contract view</title>
	<style type="text/css">
		*{
			padding: 0px;
			margin: 0px;
		}
		body{
			font-family: arial;
			background: #333;
			font-size: 18px;
		}
		.content{
			width: 60%;
			background: white;
			height: 800px;
			box-shadow: 0px 0px 10px 5px #222;
			text-align: left;
			padding: 50px 100px;
		}
		.content .heading{
			font-weight: bold;
			font-size: 18px;
		}
		.content .heading img{
			width: 160px;
			float: right;
		}
		.footer{
			margin-top: 30px;
			float: right;
			text-align: right;
		}
	</style>
</head>
<body>
	<p id="print" onclick="window.print();" style="color: #fff;padding: 10px 20px;border-radius: 5px; float: left; background: #09f;margin: 20px;cursor: pointer;">Print</p>
<center>
<div class="content">
	<div class="heading">
		<img src="images/payma2.jpg" height="200" width="300">
		
		<p>PAYMATIC LTD</p>
		
	</div>
	<br><br><br><br><br><br>
	<h2 style="text-align: center;text-decoration: underline;"> <?php
		include('connection.php');
		$result = mysqli_query($db_con,"SELECT * FROM contracts WHERE id='".$_GET['key']."'");
		$row = mysqli_fetch_array($result);
		
		if($_GET['type'] == 'Supply'){
			echo "CERTIFICATE";
			$result_sup = mysqli_query($db_con,"SELECT * FROM suppliers WHERE id_card='".$row['supplier']."'");
			$row_sup = mysqli_fetch_array($result_sup);
			$contractor = 'Owner';
		}else{
			echo "CERTIFICATE";
			$result_sup = mysqli_query($db_con,"SELECT * FROM distributors WHERE id_card='".$row['distributor']."'");
			$row_sup = mysqli_fetch_array($result_sup);
			$contractor = 'Distributor';
		}
	?></h2>
	<br><br>
	<div class="body">
		<?php

		echo"This is to confirm that <b>".$row_sup['f_name']." ".$row_sup['l_name']."</b> whose vehicle plate is <b>".$row_sup['id_card']."</b> and address as <b>".$row_sup['district']." - ".$row_sup['sector']."</b> has full filled all requirements.";
			
		echo" <br><br>
			This contract is valid from <b>".$row['starting_date']."</b> up to <b>".$row['ending_date']."</b>,.";

			echo"<br><br><br><b>$contractor:</b><br>".$row_sup['f_name']." ".$row_sup['l_name']."
			<br>Date: ".$row['starting_date']."<br><br>
			Signatute:
			<br><br>
			
			<br>Date: ".$row['starting_date']."<br><br>
			Signature:";
		?>
	</div>
	<div class="footer">
		<?php	
			echo"Managing Director, <b>Yves SHIRIMPUMU</b><br>
			<br>Date: ".$row['starting_date']." <br><br><br>
			Stamp and Signature";	
		?>
	</div>
</div>
</center>
</body>
</html>