<!DOCTYPE html>
<html>
<head>
	<title>Certificates</title>
</head>
<body>
<?php
	include('header.php');
	include('contracts_cont.php');
?>


</body>
</html>