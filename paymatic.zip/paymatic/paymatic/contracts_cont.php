<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<head>
	<title></title>
	<style type="text/css">
		.close{
			float: right;
			color: white;
		}
		.close a{
			color: white;
			background: #c00;
			padding: 0px 5px;
			border-radius: 50%;
			position: relative;
			left: 20px;
		}
		.content{
			background: white;
			width: 500px;
			padding: 10px;
			box-shadow: 0px 0px 10px 3px gray;
			position: fixed;
			top: 90px;
			left: 220px;
			height: 105%;
			width: 80%;
		}
		.content .newbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 250px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .newbox .newboxform{
			width: 270px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
		}
		.content .newbox .newboxform form input[type='text'],
		.content .newbox .newboxform form select,
		.content .newbox .newboxform form input[type='date'],
		.content .newbox .newboxform form input[type='password']{
			padding: 10px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 20px;
		}
		.content .newbox .newboxform form select{
			width: 260px;
		}
		.content .newbox .newboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .newbox .newboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .allbox .header{
			width: 700px;
		}
		.content .allbox .header form{
			float: right;
			margin-top: 
		}
		.content .allbox .header form input[type='text']{
			padding: 6px 20px;
			border: 1px solid #999;
			width: 150px;
			margin-bottom: 20px;
		}
		.content .allbox .header form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .allbox .header form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .allbox{
			float: right;
			max-width: 770px;
		}
		.content .allbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .allbox .all{;
			padding: 5px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			padding-bottom: 10px;
			border-top: none;
			width: 750px;
			position: relative;
			height: 460px;
			overflow-y: scroll;
		}
		.content .allbox .all .item{
			min-height: 50px;
			margin-bottom: 10px;
			border-bottom: 2px solid #ccc;
			padding: 10px;
		}
		.content .allbox .all .item img{
			background: #8ea83d;
			width: 25px;
			height: 30px;
			padding: 10px;
			border-radius: 5px 0% 50% 50%;
			float: left;
		}
		.content .allbox .all .item p{
			border: 2px solid #8ea83d;
			padding: 5px 10px;
			float: left;
			margin-left: -5px;
			border-radius: 0px 20px 20px 0px;
			color: #8ea83d;
		}
		.content .allbox .all .item .about{
			float: right;
			margin-top: -40px;
		}
		.content .allbox .all .item .about table{
			width: 350px;
		}
		.content .allbox .all .item .about .value{
			text-align: right;
			font-weight: bold;
			color: #0077ff;
			font-size: 15px;
		}
		.status-a{
			margin-bottom: 5px;
			border: 1px solid #0099ff;
			padding: 4px;
			padding-left: 0px;
			width: 130px;
			color: #0099ff;
			border-radius: 20px 20px 5px 5px;
		}
		.status-a span{
			background: #0099ff;
			color: white;
			padding: 5px 10px;
			margin-right: 10px;
			border-radius: 15px 0px 0px 5px;
		}
		.status-e{
			margin-bottom: 5px;
			border: 1px solid #e62146;
			padding: 4px;
			padding-left: 0px;
			width: 130px;
			color: #e62146;
			border-radius: 20px 20px 5px 5px;
		}
		.status-e span{
			background: #e62146;
			color: white;
			padding: 5px 10px;
			margin-right: 7px;
			border-radius: 15px 0px 0px 5px;
		}
		.update_model{
			position: fixed;
			width: 100%;
			height: 100%;
			background: rgba(0,0,0,.8);
		}
		.update_model .updatebox{
			box-shadow: 0px 0px 10px 5px black;
			position: absolute;
			left: 50%;
			transform: translate(-50%);
			top: 60px;
			border-radius: 10px;
		}
		.update_model .updatebox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 250px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.update_model .updatebox .updateboxform{
			width: 270px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
			background: #fff;
		}
		.update_model .updatebox .updateboxform form input[type='text'],
		.update_model .updatebox .updateboxform form select,
		.update_model .updatebox .updateboxform form input[type='date']{
			padding: 8px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 15px;
		}
		.update_model .updatebox .updateboxform form select{
			width: 260px;
		}
		.update_model .updatebox .updateboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.update_model .updatebox .updateboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.update_model .updatebox .updateboxform  form input[type='submit1']:hover{
			background: #fff;
			color: #041f3e;
		}
	</style>
</head>
<body>
<div class="content">
<CENTETR>	<h2 style="color: #333;">::PAYMATIC  :: CERTIFICATES</h2><br> <HR><br><br></CENTER>
	<div class="allbox"> 
		<div class="header"><form><script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("backend-search.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
        $(this).parent(".result").empty();
    });
});
</script>
			<input type="text" maxlength='30'name="certificates" placeholder="Search..." required>
	
			<input type="submit" value="Search">&nbsp;&nbsp;&nbsp;<input type="button" onclick="window.location.href = 'products.php';" value="View Expired Certificates"/>
		</form> All Certificates</div><HR>
		<div class="all" name="all">
			
			<?php
			$result = mysqli_query($db_con,"SELECT * FROM certificates ORDER BY plate DESC");
			while($row = mysqli_fetch_array($result)){
					echo"<div class='item'><h3 style='text-decoration: underline;'></h3><br>
					
					<div class='links' style='float: right;'>
					
						
						<a style='margin-left: 20px; padding: 5px 10px; background: #069B21; color: #fff;border-radius: 20px;' href='?update_cont=".$row['plate']."'>Update</a>
						<a style='margin-left: 20px; padding: 5px 10px; background: #FA1B05    ; color: #fff;border-radius: 20px;' href='server.php?delete_cont=".$row['plate']."'>Delete</a>
						
					</div>"; 
					
						$today = date('Y-m-d');
						if($row['endingdate'] >= $today){
							echo"<div class='status-a'><span>Status</span>Active</div>";
						}
						else{
							echo"<div class='status-e'><span>Status</span>Expired</div>";
							if($row['sms'] == 0){
								$phonenumber = $row['telephone'];
								//Send notification sms
$to=$phonenumber;
$msg="Muraho neza, turabamenyesha ko certificate y'imodoka yanyu yarangiye. Murasabwa kwihutira kongeresha igihe. Hamagara 0788730014,0788444316,0788242412";
$from='PAYMATIC';
header('Location:http://rslr.connectbind.com:8080/bulksms/bulksms?username=clr-paymaticltd&password=Pay2020&type=0&dlr=1&destination='.$to.'&source='.$from.'&message='.$msg.'');



								mysqli_query($db_con,"UPDATE certificates SET sms='1' WHERE plate='".$row['plate']."'");
								
							}
						}
						echo"<img src='images/profile.png'>
						<p>".$row['plate']."</p>
						<br><br><label style='color: #888;'>".$row['owner']."</label>
						<div class='about'>
							<table><tr>
							<td>Duration: </td><td class='value'>".$row['startdate']." To ".$row['endingdate']."</td></tr><tr>
							</tr></table>
						</div>
					</div>";
			}
			?>
		</div>
	</div>
	<script type="text/javascript">
        function num_validation(e) {
            var k = e.keyCode;
            return (k == 8   || (k >= 48 && k <= 57));

        }
    </script>
	<div class="newbox">
	    
	    
		<div class="header">Register a new Certificate</div>
		<div class="newboxform">
			<form method="POST" action='sendnew.php' >
				Plate Number:<br>
				<input type="text" name="plate"  placeholder="ex: RAD234X" required maxlength="7"><br>
				Owner:<br>
				<input type="text" name="owner"  placeholder="Vehicle Owner" required><br>
				Contact:<br>
				<input type="text" name="telephone"  placeholder="250...Owner Phone number" required onkeypress="return num_validation2(event)" maxlength="12"><br>
				Fitted Date:<br>
				<input type="date" name="stdate" required><br>
				Expiry Date:<br>
				<input type="date" name="endate" required><br>
				<br>
				 <input type="submit" name="newcont" value="Submit" onclick="return confirm('Are you sure you want to save?')";"> </p>


			</form>
		</div>
	</div>
</div>


<?php
if(isset($_GET['sup_error'])){
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='contracts.php'>&times;</a></div>Supplier error detected</div>
			<div class='updateboxform'>";
				echo"<p style='font-weight: bold;'>This <span style='color: #c00;'>".$_GET['sup_error']."</span> ID card 
				<br><br>is not found.</p>
			</div>
		</div>
	</div>";
}
elseif(isset($_GET['dis_error'])){
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='contracts.php'>&times;</a></div>Distributor error detected</div>
			<div class='updateboxform'>";
				echo"<p style='font-weight: bold;'>This <span style='color: #c00;'>".$_GET['dis_error']."</span> ID card 
				<br><br>is not found.</p>
			</div>
		</div>
	</div>";
}
elseif(isset($_GET['date_error'])){
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='contracts.php'>&times;</a></div>Date error detected</div>
			<div class='updateboxform'>
			<p style='font-weight: bold;'>Contract Period selected is invalid.</p>
			</div>
		</div>
	</div>";
}
if(isset($_GET['update_cont'])){
	$result_up = mysqli_query($db_con,"SELECT * FROM certificates WHERE plate='".$_GET['update_cont']."'");
	$row_up_count = mysqli_num_rows($result_up);
	$row_up = mysqli_fetch_array($result_up);
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='contracts.php'>&times;</a></div>Update Certificate</div>
				<div class='updateboxform'>";
				if($row_up > 0){
					echo"<form method='POST' action='sendupdate.php'>
					<input type='text' name='owner' placeholder='' required value='".$row_up['owner']."'><br>
					<input type='text' name='telephone' placeholder='' required value='".$row_up['telephone']."'><br>
					<input type='text' style='background: #ddd; cursor: not-allowed;' readonly name='plate' placeholder='' required value='".$row_up['plate']."'><br>
					Starting date:<br>
					<input type='date' name='stdate' required value='".$row_up['startdate']."'><br>
					Ending date:<br><br>
					<input type='date' name='endate' required value='".$row_up['endingdate']."'><br>
					
					<input type='submit' name='updatecont' value='Save changes'>
				</form>";
				}
			echo"</div>
		</div>
	</div>";
}
?>
<?php
if(isset($_GET['certificates'])){
	$result_up = mysqli_query($db_con,"SELECT * FROM certificates WHERE plate='".$_GET['certificates']."' OR owner='".$_GET['certificates']."'");
	$row_up_count = mysqli_num_rows($result_up);
	$row_up = mysqli_fetch_array($result_up);
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='employee.php'>&times;</a></div>Results Found</div>
			<div class='updateboxform'>";
				if($row_up > 0){
				echo"<form method='POST' action='server.php'>
					Plate:<br>
					<input type='text' name='idcard' placeholder='Plate' required value='".$row_up['plate']."' minlength='16' maxlength='16' style='background: #ddd; cursor: not-allowed;' readonly><br>
					Owner:<br>
					<input type='text' name='f_name' placeholder='Owner' required value='".$row_up['owner']."' onkeypress='return onlyAlphabets(event)' maxlength='30'><br>
					Start:<br>
					<input type='text' name='l_name' placeholder='Start' required value='".$row_up['startdate']."' onkeypress='return onlyAlphabets(event)' maxlength='30'><br>
					Ending:<br>
					<input type='text' name='country' placeholder='Ending' required value='".$row_up['endingdate']."' onkeypress='return onlyAlphabets(event)' maxlength='30'><br>

					
				</form>";
				?><?php 
				$today = date('Y-m-d');
						if($row['endingdate'] > $today){
							echo"<div class='status-a'><span>Status</span>Active</div>";
						}
				}
				else{
					echo"<p>No records found corresponding data <br><br><span>".$_GET['certificates']."</span> Data .</p>";
				}
			echo"</div>
		</div>
	</div>";
}
if(isset($_GET['error'])){
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='employee.php'>&times;</a></div>Duplicate error detected</div>
			<div class='updateboxform'>";
				echo"<p>Another employee is registerd with <br><br><span>".$_GET['error']."</span> ID card,<br>".$_GET['names']."
				<br><br>Change the ID and try again.</p>
			</div>
		</div>
	</div>";
}
?>

	<script type="text/javascript">
        function num_validation(e) {
            var k = e.keyCode;
            return (k == 8   || (k >= 48 && k <= 57));

        }
        function num_validation2(e) {
            var k = e.keyCode;
            return (k == 8   || (k >= 48 && k <= 57));

        }
        function onlyAlphabets(e) {
		    try {
		        if (window.event) {
		            var charCode = window.event.keyCode;
		        }
		        else if (e) {
		            var charCode = e.which;
		        }
		        else { return true; }
		        if (charCode == 32 || (charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
		            return true;
		        else
		            return false;
		    }
		    catch (err) {
		        alert(err.Description);
		    }
		}
        
    </script>
</body>
</html>