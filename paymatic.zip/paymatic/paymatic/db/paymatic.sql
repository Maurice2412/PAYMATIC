-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2019 at 07:38 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.0.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `daily_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `contracts`
--

CREATE TABLE `contracts` (
  `id` int(11) NOT NULL,
  `product` varchar(50) NOT NULL,
  `starting_date` date NOT NULL,
  `ending_date` date NOT NULL,
  `supplier` varchar(16) NOT NULL,
  `distributor` varchar(16) NOT NULL,
  `approval` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contracts`
--

INSERT INTO `contracts` (`id`, `product`, `starting_date`, `ending_date`, `supplier`, `distributor`, `approval`) VALUES
(15, 'Milk', '2019-09-26', '2019-10-30', '1199980040669136', '', 'ntihemuka'),
(16, 'Cheese', '2019-09-27', '2019-10-20', '', '1199980040669136', 'ntihemuka'),
(17, 'Milk', '2019-09-10', '2019-09-15', '', '1199980098761200', 'ntihemuka'),
(18, 'Cheese', '2019-09-28', '2019-11-30', '1198380034876112', '', 'ntihemuka'),
(22, 'Milk', '2019-09-02', '2019-09-02', '1199980040669136', '', 'ntihemuka'),
(24, 'Cheese', '2019-09-26', '2019-10-17', '1198380034876112', '', 'ntihemuka'),
(26, 'Milk', '2019-09-10', '2019-10-06', '1199670099976598', '', 'ntihemuka'),
(27, 'Cheese', '2019-09-10', '2019-11-09', '', '1199980098761200', 'ntihemuka'),
(30, 'Cheese', '2019-09-27', '2019-10-04', '1199622233354687', '', 'ntihemuka'),
(31, 'yogurt vanilla', '2019-09-26', '2019-10-30', '', '1991877345612200', 'ntihemuka'),
(32, 'strawberry', '2019-09-26', '2019-10-27', '1199622233354687', '', 'ntihemuka'),
(33, 'strawberry chocolate', '2019-09-26', '2019-10-04', '', '1997800981234556', 'ntihemuka'),
(34, 'ikivuguto', '2019-09-26', '2019-10-05', '', '1198078800213456', 'ntihemuka'),
(35, 'Milk', '2019-10-06', '2019-10-27', '', '1198078800213456', 'ntihemuka');

-- --------------------------------------------------------

--
-- Table structure for table `distributions`
--

CREATE TABLE `distributions` (
  `id` int(11) NOT NULL,
  `product` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `distributor` varchar(16) NOT NULL,
  `approval` varchar(50) NOT NULL,
  `t_date` date NOT NULL,
  `seen` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distributions`
--

INSERT INTO `distributions` (`id`, `product`, `quantity`, `price`, `distributor`, `approval`, `t_date`, `seen`) VALUES
(4, 'Cheese', 30, 2500, '1199980040669136', 'ntihemuka', '2019-08-17', 0),
(7, 'Milk', 56, 120, '1199980098761200', 'ntihemuka', '2019-08-19', 1),
(8, 'Milk', 40, 250, '1199980098761200', 'ntihemuka', '2019-09-10', 1),
(10, 'Cheese', 100, 2400, '1199980098761200', 'ntihemuka', '2019-09-10', 1),
(13, 'yogurt vanilla', 2000, 2400, '1991877345612200', 'ntihemuka', '2019-09-26', 0),
(14, 'yogurt vanilla', 4000, 2000, '1991877345612200', 'ntihemuka', '2019-09-26', 0),
(15, 'strawberry chocolate', 8000, 2000, '1997800981234556', 'ntihemuka', '2019-09-26', 0),
(16, 'strawberry chocolate', 150, 1200, '1997800981234556', 'ntihemuka', '2019-09-26', 0),
(17, 'ikivuguto', 100, 2000, '1198078800213456', 'ntihemuka', '2019-09-26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `distributors`
--

CREATE TABLE `distributors` (
  `id_card` varchar(16) NOT NULL,
  `f_name` varchar(25) NOT NULL,
  `l_name` varchar(25) NOT NULL,
  `country` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `district` varchar(25) NOT NULL,
  `sector` varchar(25) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `joinedon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distributors`
--

INSERT INTO `distributors` (`id_card`, `f_name`, `l_name`, `country`, `province`, `district`, `sector`, `phone`, `username`, `password`, `joinedon`) VALUES
('1198078800213456', 'AGANZE', 'Jimmy', 'RWANDA', 'NORTHERN', 'MUSANZE', 'MUHOZA', '+250789098765', 'JIMMY', '1234', '26, Sep 2019'),
('1199980040669136', 'Melchi Roger', 'GIRINEZA', 'Rwanda', 'North', 'Musanze', 'Cyuve', '0781733459', 'Roger Rolix', 'Rolix123', '17, Aug 2019'),
('1199980098761200', 'TUYUSHIME', 'Serapie', 'Rwanda', 'North', 'MUSANZE', 'CYUVE', '0784858705', 'tuyishime', 'tuyishime', '19, Aug 2019'),
('1991877345612200', 'KAMANZI', 'Olivier', 'RWANDA', 'WESTERN', 'NYABIHU', 'MUKAMIRA', '+250788876543', 'KAMANZI', '1234', '26, Sep 2019'),
('1997800981234556', 'MURIGO INNOCENT', '', 'RWANDA', 'NORTHERN', 'MUSANZE', 'KIMONYI', '+250788829098', 'INNOCENT', '1234', '26, Sep 2019'),
('2345654321234567', 'ROGER', 'GIRINEZA', 'qwerty', 'qwerty', 'Gakenke', 'bigogwe', '+250987654321', 'Fred', 'asd', '06, Oct 2019');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id_card` varchar(16) NOT NULL,
  `f_name` varchar(25) NOT NULL,
  `l_name` varchar(25) NOT NULL,
  `country` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `district` varchar(25) NOT NULL,
  `sector` varchar(25) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `joinedon` varchar(50) NOT NULL,
  `admin` int(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id_card`, `f_name`, `l_name`, `country`, `province`, `district`, `sector`, `phone`, `username`, `password`, `joinedon`, `admin`) VALUES
('1196700943122222', 'MUTESI PEACE', '', 'RWANDA', 'WESTERN', 'NYABIHU', 'RAMBURA', '+250788809854', 'PEACE', '1234', '06, Oct 2019', 0),
('1196879012537000', 'KAMANZI CLEMENT', '', 'RWANDA', 'NORTHERN', 'MUSANZE', 'MUSANZE', '+250788987344', 'CLEMENT', '1234', '06, Oct 2019', 0),
('1198770023516170', 'MUSKA ALICE', '', 'RWANDA', 'WESTERN', 'NYABIHU', 'RAMBURA', '+250788900765', 'ALICE', '1234', '06, Oct 2019', 0),
('1198776555299000', 'MUHOZA CYTHIA', '', 'RWANDA', 'NORTHERN', 'MUSANZE', 'MUHOZA', '+250787227900', 'CYTHIA', '1234', '06, Oct 2019', 0),
('1198854231210022', 'ABEZA', 'ALICE', 'RWANDA', 'NYABIHU', 'NYABIHU', 'BIGOGWE', '+250789003421', 'ALINE', '1234', '06, Oct 2019', 0),
('1199680012345666', 'MUKESHA JANET', '', 'RWANDA', 'WESTERN', 'NYABIHU', 'KARAGO', '+250788987099', 'JANET', '1234', '06, Oct 2019', 0),
('1199680092750129', 'Ntihemuka  Murigo', '', 'Rwanda', 'West', 'Nyabihu', 'Bigogwe', '0788466520', 'ntihemuka', 'aline123', '12/06/2019', 1),
('1199680092900129', 'AMANI KABERA', '', 'RWANDA', 'NORTHERN', 'MUSANZE', 'KIMONYI', '+25013454132', 'AMANI', '1234', '12, Sep 2019', 0),
('1199800543212789', 'MUSORE JIMMY', '', 'RWANDA', 'NORTHERN', 'MUSANZE', 'MUSANZE', '+250789065432', 'JIMMY', '123', '06, Oct 2019', 0),
('1199880098564120', 'NDAMIYE JOHN', '', 'RWANDA', 'WESTERN', 'NYABIHU', 'JENDA', '+250788423333', 'JOHN', '1234', '06, Oct 2019', 0),
('1199980040669136', 'ROGER', 'GIRINEZA', 'RWANDA', 'NORTHERN', 'MUSANZE', 'CYUVE', '0781733459', 'ROGER ROLIX', 'aline', '25, Jul 2019', 0),
('1199980092750120', 'KARISA', 'JEAN', 'RWANDA', 'NORTHERN', 'MUSANZE', 'CYUVE', '+25078885690', 'karisa', '123', '20, Sep 2019', 0),
('1231231231231231', 'qwerty', 'qwerty', 'qwerty', 'qwerty', 'qwerty', 'qwerty', '+250123456', 'isaac', '123', '06, Oct 2019', 0),
('199780075920129', 'NTIHEMUKA FRED', '', 'RWANDA', 'NORTHERN', 'MUSANZE', 'CYUVE', '0787000744', 'FRED', '1234', '07, Aug 2019', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` varchar(10) NOT NULL,
  `stock` varchar(50) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `stock`) VALUES
(6, 'Milk', '300 Rwf', '390'),
(7, 'Cheese', '2450', '9900'),
(8, 'ikivuguto', '4000', '14900'),
(9, 'yogurt vanilla', '2000', '6000'),
(10, 'strawberry', '3000', '5000'),
(11, 'strawberry chocolate', '1500', '7850'),
(12, 'drinking yogurt vanilla', '8500', '7000'),
(13, 'flouved milk ', '7000', '12000'),
(14, 'uht whole milk', '6000', '10000');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id_card` varchar(16) NOT NULL,
  `f_name` varchar(25) NOT NULL,
  `l_name` varchar(25) NOT NULL,
  `country` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `district` varchar(25) NOT NULL,
  `sector` varchar(25) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `joinedon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id_card`, `f_name`, `l_name`, `country`, `province`, `district`, `sector`, `phone`, `username`, `password`, `joinedon`) VALUES
('1198380034876112', 'MUHIRE CLEMENT', '', 'RWANDA', 'WESTERN', 'NYABIHU', 'MUKAMIRA', '0783239047', 'CLE', 'isaac', '19, Aug 2019'),
('1199622233354687', 'DUSABE MARIE', '', 'RWANDA', 'WESTERN', 'NYABIHU', 'BIGOGWE', '+25023456789', 'MARIE', '876', '13, Sep 2019'),
('1199670099976598', 'MUHOZA SANDRA', '', 'RWANDA', 'NORTHERN', 'MUSANZE', 'MUHOZA', '0788253377', 'SANDRA', 'sandra', '21, Aug 2019'),
('1199980040669136', 'ROGER', 'Uwayo', 'RWANDA', 'NORTHERN', 'MUSANZE', 'CYUVE', '0781733459', 'ROGER ROLIX', 'Rolix123', '17, Aug 2019'),
('1234567654321234', 'Roger', 'Melchi', 'qwerty', 'qwerty', 'qwerty', 'Nyange', '+25023456789', 'Fred', 'asd', '06, Oct 2019');

-- --------------------------------------------------------

--
-- Table structure for table `supplies`
--

CREATE TABLE `supplies` (
  `id` int(11) NOT NULL,
  `product` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `supplier` varchar(16) NOT NULL,
  `f_name` varchar(25) NOT NULL,
  `l_name` varchar(25) NOT NULL,
  `approval` varchar(50) NOT NULL,
  `t_date` date NOT NULL,
  `seen` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplies`
--

INSERT INTO `supplies` (`id`, `product`, `quantity`, `price`, `supplier`, `f_name`, `l_name`, `approval`, `t_date`, `seen`) VALUES
(12, 'Milk', 12, 245, '1199670099976598', '', '', 'ntihemuka', '2019-09-10', 1),
(13, 'Milk', 120, 185, '1199670099976598', '', '', 'ntihemuka', '2019-09-10', 1),
(15, 'Cheese', 10000, 4000, '1199622233354687', '', '', 'ntihemuka', '2019-09-26', 0),
(16, 'strawberry', 5000, 3000, '1199622233354687', '', '', 'ntihemuka', '2019-09-26', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contracts`
--
ALTER TABLE `contracts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `distributions`
--
ALTER TABLE `distributions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `distributors`
--
ALTER TABLE `distributors`
  ADD PRIMARY KEY (`id_card`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id_card`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id_card`);

--
-- Indexes for table `supplies`
--
ALTER TABLE `supplies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contracts`
--
ALTER TABLE `contracts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `distributions`
--
ALTER TABLE `distributions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `supplies`
--
ALTER TABLE `supplies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
