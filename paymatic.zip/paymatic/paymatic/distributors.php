<!DOCTYPE html>
<html>
<head>
	<title>Suppliers</title>
</head>
<body>
<?php
	include('header.php');
	include('dis_cont.php');
?>
</body>
</html>