<!DOCTYPE html>
<html>
<head>
	<title>Employees</title>
</head>
<body>
<?php
	include('header.php');
	include('employee_cont.php');
?>
</body>
</html>