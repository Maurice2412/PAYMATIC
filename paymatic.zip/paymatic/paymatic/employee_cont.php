<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.close{
			float: right;
			color: white;
		}
		.close a{
			color: white;
			background: #c00;
			padding: 0px 5px;
			border-radius: 50%;
			position: relative;
			left: 20px;
		}
		.content{
			background: white;
			width: 500px;
			padding: 10px;
			box-shadow: 0px 0px 10px 3px gray;
			position: fixed;
			top: 90px;
			left: 220px;
			height: 105%;
			width: 80%;
		}
		.content .newbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 250px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .newbox .newboxform{
			width: 270px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
		}
		.content .newbox .newboxform form input[type='text'],
		.content .newbox .newboxform form input[type='password']{
			padding: 7px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 10px;
		}
		.content .newbox .newboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .newbox .newboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .allbox .header{
			width: 700px;
		}
		.content .allbox .header form{
			float: right;
			margin-top: 
		}
		.content .allbox .header form input[type='text']{
			padding: 6px 20px;
			border: 1px solid #999;
			width: 150px;
			margin-bottom: 20px;
		}
		.content .allbox .header form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .allbox .header form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .allbox{
			float: right;
			max-width: 770px;
		}
		.content .allbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .allbox .all{;
			padding: 5px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			padding-bottom: 10px;
			border-top: none;
			width: 750px;
			overflow: scroll;
			position: relative;
			top: -17px;
			height: 400px;
		}
		.content .allbox .all table{
			width: 200%;
		}
		.content .allbox .all table tr .tdheader{
			background: #ff9900;
			color: white;
			padding: 5px 15px;
			font-size: 15px;
		}
		.content .allbox .all table tr td{
			background: #ccc;
			color: #555;
			padding: 5px 10px;
			font-size: 13px;
		}
		.content .allbox .all table tr td img{
			width: 15px;
			height: 15px;
			color: #0099ff;
		}
		.content .allbox .all table tr td a{
			color: #0099ff;
		}
		.content .allbox .all table tr td a:hover{
			text-decoration: underline;
		}
		.update_model{
			position: fixed;
			width: 100%;
			height: 100%;
			background: rgba(0,0,0,.8);
		}
		.update_model .updatebox{
			box-shadow: 0px 0px 10px 5px black;
			position: absolute;
			left: 50%;
			transform: translate(-50%);
			top: 30px;
			border-radius: 10px;
		}
		.update_model .updatebox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 250px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.update_model .updatebox .updateboxform{
			width: 270px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
			background: #fff;
			overflow-y: scroll;
			max-height: 500px;
		}
		.update_model .updatebox .updateboxform form input[type='text'],
		.update_model .updatebox .updateboxform form input[type='password']{
			padding: 5px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 10px;
		}
		.update_model .updatebox .updateboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.update_model .updatebox .updateboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.update_model .updatebox span{
			font-weight: bold;
			color: #c00;
		}
	</style>
</head>
<body>
<div class="content">
	<h2 style="color: #333;"> PAYMATIC ::  Employees</h2><br>
	<div class="allbox">
		<div class="header">
		<form>
			<input type="text" maxlength='30'name="employee" placeholder="Search..." required>
			<input type="submit" value="Search">
		</form>
		All registered employees</div>
		<div class="all">
			<table>
				<tr>
					<td class="tdheader">Names</td>
					<td class="tdheader">Username</td>
					<td class="tdheader">Address</td>
					<td class="tdheader">Phone</td>
					<td class="tdheader" colspan="2">Options</td>
				</tr>
				<?php
				$result = mysqli_query($db_con,"SELECT * FROM employees");
				while($row = mysqli_fetch_array($result)){
					echo"<tr>
					<td>".$row['names']."</td>
					<td>".$row['username']."</td>
					<td>".$row['address']."</td>
					<td>".$row['phone']."</td>
					
					<td>
						<img src='images/edit.png'>
						<a href='?employee=".$row['id_card']."'>Edit</a>
					</td>
					<td>
						<img src='images/delete.png'>
						<a href='server.php?delete_emp=".$row['id_card']."'>Delete</a>
					</td>
				</tr>";
				}
				?>
			</table>
		</div>
	</div>
	<script type="text/javascript">
        function num_validation(e) {
            var k = e.keyCode;
            return (k == 8   || (k >= 48 && k <= 57));

        }
        function num_validation2(e) {
            var k = e.keyCode;
            return (k == 8   || (k >= 48 && k <= 57));

        }
        function onlyAlphabets(e) {
		    try {
		        if (window.event) {
		            var charCode = window.event.keyCode;
		        }
		        else if (e) {
		            var charCode = e.which;
		        }
		        else { return true; }
		        if (charCode == 32 || (charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
		            return true;
		        else
		            return false;
		    }
		    catch (err) {
		        alert(err.Description);
		    }
		}
        
    </script>
	<div class="newbox"> 
		<div class="header">Register a new employee</div>
		<div class="newboxform" style="overflow-y: scroll; max-height: 400px;">
			<form method="POST" action='server.php'>
				Names:<br>
				<input type="text" name="names" placeholder="Names" required onkeypress="return onlyAlphabets(event)" maxlength="30"><br>
				Address:<br>
				<input type="text" name="address" placeholder="Addres: " required onkeypress="return onlyAlphabets(event)" maxlength="30"><br>
				
				Phone number:<br>
				<select name="phone" style="padding: 7px 5px;">
					<option>+250</option>
				</select>
				<input style="width: 140px;" minlength='9' maxlength='9' type="text" name="phone" placeholder="Phone number" required onkeypress="return num_validation2(event)"/><br>
				Username:<br>
				<input type="text" name="username" placeholder="Username" required maxlength="30"><br>
				Password:<br>
				<input type="password" name="password" placeholder="Password" required maxlength="30"><br>
				<input type="submit" name="addnewemp" value="Add new">
				<br><br>
			</form>
		</div>
	</div>
</div>
<?php
if(isset($_GET['employee'])){
	$result_up = mysqli_query($db_con,"SELECT * FROM employees WHERE id_card='".$_GET['employee']."' OR f_name='".$_GET['employee']."' OR l_name='".$_GET['employee']."'");
	$row_up_count = mysqli_num_rows($result_up);
	$row_up = mysqli_fetch_array($result_up);
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='employee.php'>&times;</a></div>Employee view</div>
			<div class='updateboxform'>";
				if($row_up > 0){
				echo"<form method='POST' action='server.php'>
					National ID card:<br>
					<input type='text' name='idcard' placeholder='National ID card' required value='".$row_up['id_card']."' minlength='16' maxlength='16' style='background: #ddd; cursor: not-allowed;' readonly><br>
					First name:<br>
					<input type='text' name='f_name' placeholder='First name' required value='".$row_up['f_name']."' onkeypress='return onlyAlphabets(event)' maxlength='30'><br>
					Last name:<br>
					<input type='text' name='l_name' placeholder='Last name' required value='".$row_up['l_name']."' onkeypress='return onlyAlphabets(event)' maxlength='30'><br>
					Country:<br>
					<input type='text' name='country' placeholder='Addres: Country' required value='".$row_up['country']."' onkeypress='return onlyAlphabets(event)' maxlength='30'><br>
					Province:<br>
					<input type='text' name='province' placeholder='Addres: Province' required value='".$row_up['province']."' onkeypress='return onlyAlphabets(event)' maxlength='30'><br>
					District:<br>
					<input type='text' name='district' placeholder='Addres: District' required value='".$row_up['district']."' onkeypress='return onlyAlphabets(event)' maxlength='30'><br>
					Sector:<br>
					<input type='text' name='sector' placeholder='Addres: Sector' required value='".$row_up['sector']."' onkeypress='return onlyAlphabets(event)' maxlength='30'><br>
					Phone number:<br>
					<input type='text' name='phone' onkeypress='return num_validation(event)' placeholder='Phone number' minlength='9' maxlength='9' required value='".$row_up['phone']."'><br>
					Username:<br>
					<input type='text' name='username' placeholder='Username' required value='".$row_up['username']."' maxlength='30'><br>
					Password:<br>
					<input type='text' name='password' placeholder='Password' required value='".$row_up['password']."' maxlength='30'><br>
					<input type='hidden' name='employee' value='".$row_up['id_card']."'>
					<input type='submit' name='updatemp' value='Save changes'>
				</form>";
				}
				else{
					echo"<p>No records found corresponding <br><br><span>".$_GET['employee']."</span> ID card.</p>";
				}
			echo"</div>
		</div>
	</div>";
}
if(isset($_GET['error'])){
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='employee.php'>&times;</a></div>Duplicate error detected</div>
			<div class='updateboxform'>";
				echo"<p>Another employee is registerd with <br><br><span>".$_GET['error']."</span> ID card,<br>".$_GET['names']."
				<br><br>Change the ID and try again.</p>
			</div>
		</div>
	</div>";
}
?>
</body>
</html>