<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.close{
			float: right;
			color: white;
		}
		.close a{
			color: white;
			background: #c00;
			padding: 0px 5px;
			border-radius: 50%;
			position: relative;
			left: 20px;
		}
		.content{
			background: white;
			width: 500px;
			padding: 10px;
			box-shadow: 0px 0px 10px 3px gray;
			position: fixed;
			top: 90px;
			left: 220px;
			height: 105%;
			width: 80%;
		}
		.content .newbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 250px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .newbox .newboxform{
			width: 270px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
		}
		.content .newbox .newboxform form input[type='text'],
		.content .newbox .newboxform form input[type='password']{
			padding: 10px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 15px;
		}
		.content .newbox .newboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .newbox .newboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .allbox .header{
			width: 700px;
		}
		.content .allbox .header form{
			float: right;
			margin-top: 
		}
		.content .allbox .header form input[type='text']{
			padding: 6px 20px;
			border: 1px solid #999;
			width: 150px;
			margin-bottom: 20px;
		}
		.content .allbox .header form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .allbox .header form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .allbox{
			float: right;
			max-width: 770px;
		}
		.content .allbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .allbox .all{;
			padding: 5px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			padding-bottom: 10px;
			border-top: none;
			width: 750px;
			overflow: scroll;
			position: relative;
			top: -17px;
			height: 400px;
		}
		.content .allbox .all table{
			width: 80%;
		}
		.content .allbox .all table tr .tdheader{
			background: #ff9900;
			color: white;
			padding: 5px 15px;
			font-size: 15px;
		}
		.content .allbox .all table tr td{
			background: #ccc;
			color: #555;
			padding: 5px 10px;
			font-size: 13px;
		}
		.content .allbox .all table tr td img{
			width: 15px;
			height: 15px;
			color: #0099ff;
		}
		.content .allbox .all table tr td a{
			color: #0099ff;
		}
		.content .allbox .all table tr td a:hover{
			text-decoration: underline;
		}
		.update_model{
			position: fixed;
			width: 100%;
			height: 100%;
			background: rgba(0,0,0,.8);
		}
		.update_model .updatebox{
			box-shadow: 0px 0px 10px 5px black;
			position: absolute;
			left: 50%;
			transform: translate(-50%);
			top: 60px;
			border-radius: 10px;
		}
		.update_model .updatebox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 250px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.update_model .updatebox .updateboxform{
			width: 270px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
			background: #fff;
		}
		.update_model .updatebox .updateboxform form input[type='text'],
		.update_model .updatebox .updateboxform form input[type='password']{
			padding: 8px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 15px;
		}
		.update_model .updatebox .updateboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.update_model .updatebox .updateboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.update_model .updatebox span{
			font-weight: bold;
			color: #c00;
		}
	</style>
</head>
<body>
<div class="content">
	<h2 style="color: #333;">PAYMATIC ::  Products</h2><br>
	<div class="allbox">
		<div class="header">
		<form>
			<input type="text" name="product" placeholder="Search by Product name...">
			<input type="submit" value="Search">
		</form>
		All registered Products</div>
		<div class="all">
			<table>
				<tr>
					<td class="tdheader">Plate Number</td>
					<td class="tdheader">Owner</td>
					<td class="tdheader">Phone</td>
					<td class="tdheader">Date Fitted</td>
					<td class="tdheader">Expiry Date</td>
					<td class="tdheader" colspan="2">Options</td>
				</tr>
				<?php
				$today = date('Y-m-d');
			$result = mysqli_query($db_con,"SELECT * FROM certificates ");
				while($row = mysqli_fetch_array($result)){
					echo"<tr>
					<td>".$row['plate']."</td>
					<td>".$row['owner']."</td>
					<td>".$row['telephone']."</td>
					<td>".$row['startdate']."</td>
					<td>".$row['endingdate']."</td>
					
				</tr>";
				}
				?>
			</table>
		</div>
	</div>
	<div class="newbox"> 
		<div class="header">Register a new Product</div>
		<script type="text/javascript">
	        function num_validation(e) {
	            var k = e.keyCode;
	            return (k == 8   || (k >= 48 && k <= 57));

	        }
	    </script>
		<div class="newboxform">
			<form method="POST" action='server.php'>
				Product name:<br>
				<input type="text" name="pro_name" placeholder="Product name" required><br>
				Price:<br>
				<input type="text" name="price" placeholder="Price" onkeypress="return num_validation(event)"/><br>
				<input type="submit" name="addnewpro" value="Add new">
			</form>
		</div>
	</div>
</div>
<?php
if(isset($_GET['product'])){
	$result_up = mysqli_query($db_con,"SELECT * FROM products WHERE name='".$_GET['product']."'");
	$row_up_count = mysqli_num_rows($result_up);
	$row_up = mysqli_fetch_array($result_up);
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='products.php'>&times;</a></div>Product view</div>
			<div class='updateboxform'>";
				if($row_up > 0){
				echo"<form method='POST' action='server.php'>
					Product name:<br>
					<input type='text' name='pro_name' required value='".$row_up['name']."' style='background: #ddd;'><br>
					Price:<br>
					<input type='text' name='price' placeholder='Price' onkeypress='return num_validation(event)' required value='".$row_up['price']."'><br>
					<input type='hidden' name='product' value='".$_GET['product']."'>
					<input type='submit' name='updatepro' value='Save changes'>
				</form>";
				}
				else{
					echo"<p>No records found corresponding <br><br><span>".$_GET['product']."</span> ID.</p>";
				}
			echo"</div>
		</div>
	</div>";
}
if(isset($_GET['error'])){
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='products.php'>&times;</a></div>Duplicate error detected</div>
			<div class='updateboxform'>";
				echo"<p>Another product is registerd with <br><br><span>".$_GET['error']."</span> name.
				<br><br>Change the name and try again.</p>
			</div>
		</div>
	</div>";
}
?>
</body>
</html>