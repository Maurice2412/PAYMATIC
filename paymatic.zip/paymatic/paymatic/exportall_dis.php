<?php  
//export.php  
$db_con = mysqli_connect("localhost", "root", "", "daily_data");
$output = "";
if(isset($_GET["export"]))
{
  $output .= '<table>';
  $output .= "<tr><td colspan='8'><br></td></tr>";
  $output .= "<tr><td colspan='8'><br>REPUBLIC OF RWANDA</td></tr>";
  $output .= "<tr><td colspan='8'><br>NYABIHU DISTRICT</td></tr>";
  $output .= "<tr><td colspan='8'><br>MUKAMIRA DAILY</td></tr>";
  $output .= "<tr><td colspan='8'><br></td></tr>";
  $output .= "<tr><td colspan='8'><br></td></tr>";
 $result = mysqli_query($db_con,"SELECT DISTINCT(product) FROM distributions ORDER BY id DESC");
  while($row = mysqli_fetch_array($result)){
  $output .= "<tr><td colspan='8' style='padding: 10px 20px;background: #041f3e; color:#fff; font-weight: bold;'>General report for distribution of ".$row['product']."</td></tr>
    <tr>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #f90;color: white;'>Product</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #f90;color: white;'>Quantity</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #f90;color: white;'>U-P</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #f90;color: white;'>Total</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #f90;color: white;'>Distributor ID</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #f90;color: white;'>Full names</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #f90;color: white;'>Approved by</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #f90;color: white;'>Date of transaction</td>
    </tr>";
    $total_q = 0;
    $total_p = 0;
    $result_list = mysqli_query($db_con,"SELECT * FROM distributions WHERE product = '".$row['product']."' ORDER BY id DESC");
    while($row_list = mysqli_fetch_array($result_list)){
    $result_sup = mysqli_query($db_con,"SELECT * FROM distributors WHERE id_card = '".$row_list['distributor']."' ");
    $row_sup = mysqli_fetch_array($result_sup);
    $total = ($row_list['quantity'] * $row_list['price'])." Rwf";
    $total_add = ($row_list['quantity'] * $row_list['price']);
      $output .= "<tr>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row_list['product']."</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row_list['quantity']."</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row_list['price']." Rwf</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$total."</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>NID: ".$row_sup['id_card']."</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row_sup['f_name']." ".$row_sup['l_name']."</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row_list['approval']."</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row_list['t_date']."</td>
      </tr>";
      $total_q += $row_list['quantity'];
      $total_p += $total_add;
    }
    $output .= "<tr>
      <td style='font-size: 16px; background: #fff;text-align: right;' colspan='8'>Total quantity: $total_q</td>
    </tr>
    <tr>
      <td style='font-size: 16px; background: #fff;text-align: right;' colspan='8'>Total price: $total_p Rwf</td>
    </tr>
     <tr>
      <td style='font-size: 16px; background: #fff;text-align: right;' colspan='8'><br><br></td>
    </tr>";
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=Daily_general_report.xls');
  echo $output;
}
?>
