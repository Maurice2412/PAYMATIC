<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<?php
session_start();
if(!isset($_SESSION['active_admin']) AND (!isset($_SESSION['active_employee']))){
	header("location: index.php");
}
include('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		*{
			font-family: arial;
			margin: 0px;
			padding: 0px;
			text-decoration: none;
			color: #333;
		}
		body{
			background: #ddd;
		}
		.head{
			background: #041f3e;
			padding: 20px 30px;
			min-height: 30px;
			position: fixed;
			width: 100%;
		}
		.head p{
			float: left;
			color: white;
			font-weight: bold;
			font-size: 25px;
			padding-right: 10px;
		}
		.head p span{
			background: white;
			color: #041f3e;
			padding: 5px 20px;
			padding-right: 2px;
			margin-right: 2px;
		}
		.head label{
			color: #95c1f3;
			position: relative;
			top: 2px;
			font-size: 20px;
			float: left;
		}
		.head form input[type='text']{
			background: #95c1f3;
			padding: 8px 20px;
			font-size: 16px;
			border-radius: 20px;
			border: 2px solid #244b79;
			width: 400px;
			float: left;
			float: left;
		}
		.head form{
			float: right;
			margin-top: -5px;
			margin-right: 50px;
		}
		.head form img{
			position: relative;
			left: -35px;
			top: 5px;
			height: 25px;
			cursor: pointer;
		}
		.head .me{
			float: left;
			margin-right: 30px
		}
		.head .me img{
			width: 25px;
		}
		.head .me p{
			font-weight: bold;
			font-size: 16px;
			color: #95c1f3;
			float: right;
			position: none;
			margin-top: 3px;
			margin-left: 5px;
		}
		.sidemenu{
			position: fixed;
			top: 73px;
			height: 83.7%;
			width: 170px;
			background: #0d1319;
			padding: 20px;
			overflow: auto;
		}
		.sidemenu ul li{
			display: block;
			color: #ff9900;
			margin-bottom: 15px;
			border-bottom: 1px solid #555;
			padding: 10px;
			transition: all 200ms;
			padding-left: 0px;
		}
		.sidemenu ul li:hover{
			color: white;
			cursor: pointer;
			border-left: 5px solid #ff9900;
			padding-left: 15px;
		}
	</style>
</head>
<body>
<div class="head">  
	<a href='myprofile.php'><div class="me">
		<img src="images/profile.png">
		<p><?php
		if(isset($_SESSION['active_admin'])){
			echo $_SESSION['active_admin']; 
		}
		else{
			echo $_SESSION['active_employee']; 
		}
		?></p>
	</div></a>
	<p><span>PAY</span>MATIC</p><label>Ltd</label>
	<div class="serchbox">
		
	</div>
</div>
<div class="sidemenu">
	<img src="images/PAYMA.JPG" style="width: 100%; height:  70PX;margin-top: 20px;">
	<br><br>
	<ul>
		<a href='home.php'><li><i class='fas fa-tachometer-alt' style='font-size:25px;color:white'></i>  Dashboard</li></a>
		<?php
		if(isset($_SESSION['active_admin'])){
			echo"
				<a href='myprofile.php'><li><i class='far fa-id-card' style='font-size:25px;color:white'></i>  My Profile</li></a>
				<a href='employee.php'><li><i class='fas fa-users' style='font-size:25px;color:white'></i>  Employees</li></a>
				
			";
		}elseif(isset($_SESSION['active_employee'])){
			echo"<a href='myprofile.php'><li>My Profile</li></a>";
		}
		?>
		
		<a href='contracts.php'><li><i class='fas fa-award' style='font-size:25px;color:white'></i> Certificates</li></a>
		<a href='logout.php'><li><i class='fas fa-sign-out-alt' style='font-size:25px;color:white'></i>  Signout</li></a>

	</ul>
	<br>
</div>
</body>
</html>