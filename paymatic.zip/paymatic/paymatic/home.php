  <!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
</head>
<body>
<?php
	include('header.php');
	include('home_cont.php');
?>
</body>
</html>