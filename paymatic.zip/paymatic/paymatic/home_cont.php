<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.content{
			background: white;
			width: 500px;
			padding: 10px;
			box-shadow: 0px 0px 10px 3px gray;
			position: fixed;
			top: 90px;
			left: 220px;
			height: 105%;
			width: 80%;
		}
		.content .suppliers{
			float: left;
			width: 230px;
			margin: 70px 20px;
			transition: .5s;
		}
		.content .suppliers .header{
			background: #037dab;
			color: white;
			padding: 20px;
			font-weight: bold;
			font-size: 20px;
			text-align: center;
		}
		.content .suppliers .sup_content{
			border: 3px solid #037dab;
			padding: 20px;
			font-size: 17px;
			color: #037dab;
			background: #b8e4f5;
			text-align: center;
			height: 150px;
			padding-top: 50px;
			transition: .5s;
			border-bottom: 20px solid #037dab;
		}
		.content .contracts{
			float: left;
			width: 230px;
			margin: 70px 20px;
			transition: .5s;
		}
		.content .contracts .header{
			background: #598719;
			color: white;
			padding: 20px;
			font-weight: bold;
			font-size: 20px;
			text-align: center;
		}
		.content .contracts .cont_content{
			border: 3px solid #598719;
			padding: 20px;
			font-size: 17px;
			color: #598719;
			background: #d7efb7;
			text-align: center;
			height: 150px;
			padding-top: 50px;
			transition: .5s;
			border-bottom: 20px solid #598719;
		}
		.content .new{
			float: left;
			width: 230px;
			margin: 70px 20px;
			transition: .5s;
		}
		.content .new .header{
			background: #a60430;
			color: white;
			padding: 20px;
			font-weight: bold;
			font-size: 20px;
			text-align: center;
		}
		.content .new .new_content{
			border: 3px solid #a60430;
			padding: 20px;
			font-size: 17px;
			color: #a60430;
			background: #f4a9be;
			text-align: center;
			height: 150px;
			padding-top: 50px;
			transition: .5s;
			border-bottom: 20px solid #a60430;
		}
		.content .dis{
			float: left;
			width: 230px;
			margin: 70px 20px;
			transition: .5s;
		}
		.content .dis .header{
			background: #b57906;
			color: white;
			padding: 20px;
			font-weight: bold;
			font-size: 20px;
			text-align: center;
		}
		.content .dis .dis_content{
			border: 3px solid #b57906;
			padding: 20px;
			font-size: 17px;
			color: #b57906;
			background: #fae8c6;
			text-align: center;
			height: 150px;
			padding-top: 50px;
			transition: .5s;
			border-bottom: 20px solid #b57906;
		}
		.content .dist{
			float: left;
			width: 230px;
			margin: 70px 20px;
			transition: .5s;
		}
		.content .dist .header{
			background: #0e2a49;
			color: white;
			padding: 20px;
			font-weight: bold;
			font-size: 20px;
			text-align: center;
		}
		.content .dist .dist_content{
			border: 3px solid #0e2a49;
			padding: 20px;
			font-size: 17px;
			color: #0e2a49;
			background: #b6cde7;
			text-align: center;
			height: 150px;
			padding-top: 50px;
			transition: .5s;
			border-bottom: 20px solid #0e2a49;
		}
		.content .new:hover,
		.content .contracts:hover,
		.content .dis:hover,
		.content .dist:hover,
		.content .suppliers:hover{
			box-shadow: 0px 0px 20px 5px #555;
			cursor: pointer;
			margin-top: 30px;
		}
		.content .suppliers:hover .sup_content{
			border-bottom: 60px solid #037dab;
		}
		.content .contracts:hover .cont_content{
			border-bottom: 60px solid #598719;
		}
		.content .new:hover .new_content{
			border-bottom: 60px solid #a60430;
		}
		.content .dis:hover .dis_content{
			border-bottom: 60px solid #b57906;
		}
		.content .dist:hover .dist_content{
			border-bottom: 60px solid #0e2a49;
		}
	</style>
</head>
<body>
<div class="content"><br><br>
	<h2 style="color: #333;"> &nbsp &nbsp PAYMATIC :: Dashboard </h2><br><hr>
	<a href="contracts.php"><div class="contracts">
		<div class="header"><i class='fas fa-award' style='font-size:40px;color:white'></i><br><br>Valid Certificate</div>
		<div class="cont_content">
			<?php
				$today = date('Y-m-d');
				$result = mysqli_query($db_con,"SELECT * FROM certificates where endingdate >'$today'");
				$count = mysqli_num_rows($result);
				echo"$count valid now.";
			?>
		</div>
	</div></a>
	<a href="products.php"><div class="new">
		<div class="header"><i class='fas fa-award' style='font-size:40px;color:white'></i><br><br>Expired Certificate</div>
		<div class="new_content">
			<?php
				$result = mysqli_query($db_con,"SELECT * FROM certificates where endingdate <'$today'");
				$count = mysqli_num_rows($result);
				echo"$count already expired.";
			?>
	
		</div>
	</div></a><a href="suppliers.php"><div class="suppliers">
		<div class="header"><i class='fas fa-tachometer-alt' style='font-size:30px;color:white'></i><br><br>Speed Governor</div>
		<div class="sup_content">
			<?php
				$result = mysqli_query($db_con,"SELECT * FROM products where name = 'Speed Governor'");
				$count = mysqli_num_rows($result);
				echo"$count available by now.";

			?>
		</div>
	</div></a>
	
	<a href="reports.php"><div class="dist">
		<div class="header"><i class='fas fa-broadcast-tower' style='font-size:40px;color:white'></i><br><br>GPS Tracker</div>
		<div class="dist_content">
			<?php
				$result = mysqli_query($db_con,"SELECT * FROM products where name = 'GPS'");
				$count = mysqli_num_rows($result);
				echo"$count available by now.";
			?>
		</div>
	</div></a>
	
</div>
</body>
</html>