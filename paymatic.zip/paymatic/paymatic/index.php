<!DOCTYPE html>
<html>
<head>
	<title>Paymatic Ltd</title>
	<style type="text/css">
		*{
			font-family: arial;
			margin: 0px;
			padding: 0px;
			text-decoration: none;
		}
		body{
			background: #ddd;
		}
		.logo{
			position: absolute;
			width: 350px;
			top: 50px;
			left: 50%;
			transform: translate(-50%);
			text-align: center;
		}
		.logo img{
			height: 150px;
			width: 350px;
			box-shadow: 0px 0px 10px 5px gray;
		}
		.logo p{
			border: 1px solid white;
			border-top: 25px solid white;
			padding: 10px 0px;
			margin-top: -25px;
			font-size: 20px;
			color: white;
			background: #b50b03;
			box-shadow: 0px 0px 10px 5px gray;
		}
		.content{
			position: absolute;
			width: 350px;
			top: 270px;
			left: 50%;
			transform: translate(-50%);
			box-shadow: 0px 0px 10px 5px gray;
		}
		.content .header{
			border: 1px solid #fff;
			background: #041f3e;
			padding: 10px 20px;
			font-size: 25px;
			color: #fff;
			text-align: center;
		}
		.content .loginbox{
			border: 1px solid #fff;
			background: #fff;
			padding: 20px;
		}
		.content .loginbox form input[type='text'],
		.content .loginbox form input[type='password']{
			padding: 10px 20px;
			border: 1px solid #999;
			width: 80%;
			margin-bottom: 20px;
		}
		.content .loginbox form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .loginbox form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .loginbox .failed{
			color: #bb0000;
			margin-bottom: 20px;
			font-weight: bold;
		}
		.content .footer{
			border: 1px solid #fff;
			background: #52667d;
			padding: 5px 20px;
			font-size: 12px;
			color: #ddd;
			text-align: center;
		}
	</style>
</head>
<body>
<div class="logo">
	<img src="PAYMA.JPG">
	<p>PAYMATIC LTD</p>
</div>
<div class="content">
	<div class="header">Sign in here</div>
	<div class="loginbox">
		<?php
			session_start();
			if(isset($_POST['login'])){
				include('connection.php');

				
				
				
 $username= mysqli_real_escape_string($db_con, $_POST['username']);
			
 $password =mysqli_real_escape_string($db_con, $_POST['password']);
				if($username == ''){
					echo"<p class='failed'>Username is required.</p>";
				}
				elseif($password == ''){
					echo"<p class='failed'>Password is required.</p>";
				}
				else{
					$result = mysqli_query($db_con,"SELECT * FROM employees WHERE username='$username' AND password='$password'");
					$data = mysqli_fetch_array($result);
					$checkuser = mysqli_num_rows($result);
					if($checkuser > 0){
						if($data['admin'] == 1){
							$_SESSION['active_admin'] = $username;
						}
						else{
							$_SESSION['active_employee'] = $username;
						}
					//	header("location: home.php");
						echo '<script>window.location="home.php"</script>';
					
					}
					
				}
			}
		?>
		<form method="POST">
			<input type="text" name="username" placeholder="Username"><br>
			<input type="password" name="password" placeholder="Password"><br>
			<center><input type="submit" name="login" value="Sign in"></center>
			
		</form>
	</div>
	<div class="footer">
		Powered by Maurice | &copy; All rights reserved
	</div>
</div>
</body>
</html>