<?php
session_start();
unset($_SESSION['active_admin']);
header("location: index.php");
?>