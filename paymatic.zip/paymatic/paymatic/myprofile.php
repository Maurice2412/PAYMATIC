<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
</head>
<body>
<?php
	include('header.php');
	include('myprofile_cont.php');
?>
</body>
</html>