<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.close{
			float: right;
			color: white;
		}
		.close a{
			color: white;
			background: #c00;
			padding: 0px 5px;
			border-radius: 50%;
			position: relative;
			left: 20px;
		}
		.content{
			background: white;
			width: 500px;
			padding: 10px;
			box-shadow: 0px 0px 10px 3px gray;
			position: fixed;
			top: 90px;
			left: 220px;
			height: 105%;
			width: 80%;
		}
		.content .newbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 250px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .newbox .newboxform{
			width: 270px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
		}
		.content .newbox .newboxform form input[type='text'],
		.content .newbox .newboxform form select,
		.content .newbox .newboxform form input[type='date'],
		.content .newbox .newboxform form input[type='password']{
			padding: 10px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 20px;
		}
		.content .newbox .newboxform form select{
			width: 260px;
		}
		.content .newbox .newboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .newbox .newboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .allbox .header form{
			float: right;
			margin-top: 
		}
		.content .allbox .header form input[type='text']{
			padding: 6px 20px;
			border: 1px solid #999;
			width: 150px;
			margin-bottom: 20px;
		}
		.content .allbox .header form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .allbox .header form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .allbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .allbox .all{;
			padding: 5px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			padding-bottom: 10px;
			border-top: none;
			position: relative;
			height: 350px;
		}
		.content .allbox .all .item{
			min-height: 50px;
			margin-bottom: 10px;
			border-bottom: 2px solid #ccc;
			padding: 10px;
		}
		.content .allbox .all .item img{
			background: #8ea83d;
			width: 25px;
			height: 30px;
			padding: 10px;
			border-radius: 5px 0% 50% 50%;
			float: left;
		}
		.content .allbox .all .item p{
			border: 2px solid #8ea83d;
			padding: 5px 10px;
			float: left;
			margin-left: -5px;
			border-radius: 0px 20px 20px 0px;
			color: #8ea83d;
		}
		.content .allbox .all .item .about{
			float: right;
			margin-top: -40px;
		}
		.content .allbox .all .item .about table{
			width: 350px;
		}
		.content .allbox .all .item .about .value{
			text-align: right;
			font-weight: bold;
			color: #0077ff;
			font-size: 15px;
		}
		.status-a{
			margin-bottom: 5px;
			border: 1px solid #0099ff;
			padding: 4px;
			padding-left: 0px;
			width: 130px;
			color: #0099ff;
			border-radius: 20px 20px 5px 5px;
		}
		.status-a span{
			background: #0099ff;
			color: white;
			padding: 5px 10px;
			margin-right: 10px;
			border-radius: 15px 0px 0px 5px;
		}
		.status-e{
			margin-bottom: 5px;
			border: 1px solid #e62146;
			padding: 4px;
			padding-left: 0px;
			width: 130px;
			color: #e62146;
			border-radius: 20px 20px 5px 5px;
		}
		.status-e span{
			background: #e62146;
			color: white;
			padding: 5px 10px;
			margin-right: 7px;
			border-radius: 15px 0px 0px 5px;
		}
		.update_model{
			position: fixed;
			width: 100%;
			height: 100%;
			background: rgba(0,0,0,.8);
		}
		.update_model .updatebox{
			box-shadow: 0px 0px 10px 5px black;
			position: absolute;
			left: 50%;
			transform: translate(-50%);
			top: 60px;
			border-radius: 10px;
		}
		.update_model .updatebox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 250px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.update_model .updatebox .updateboxform{
			width: 270px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
			background: #fff;
		}
		.update_model .updatebox .updateboxform form input[type='text'],
		.update_model .updatebox .updateboxform form select,
		.update_model .updatebox .updateboxform form input[type='date']{
			padding: 8px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 15px;
		}
		.update_model .updatebox .updateboxform form select{
			width: 260px;
		}
		.update_model .updatebox .updateboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.update_model .updatebox .updateboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		table tr td{
			padding: 5px 20px;
			border-bottom: 1px solid #ccc;
		}
	</style>
</head>
<body>
<div class="content">
	<h2 style="color: #333;">PAYMATIC :: Profile</h2><br>
	<div class="allbox">
		<div class="header">User related data</div>
		<div class="all">
			<form method="POST" action="server.php" style="float: right;margin-right: 200px;">
				<?php
					if(isset($_SESSION['active_admin'])){
						echo"<input type='hidden' name='username' value='".$_SESSION['active_admin']."'>";
					}elseif(isset($_SESSION['active_employee'])){
						echo"<input type='hidden' name='username' value='".$_SESSION['active_employee']."'>";
					}
				?>
				<input type="password" name="new_pass" style="padding:6px 15px;" placeholder="Enter new password" required=""><br>
				<input type="password" name="new_pass" style="padding:6px 15px;" placeholder="Confirm password" required="">
				<input type="submit" name="change_pass" value="Change Password" style="padding: 10px 20px;">
			</form>
			<br>
			<?php
			if(isset($_SESSION['active_admin'])){
				$result = mysqli_query($db_con,"SELECT * FROM employees WHERE username='".$_SESSION['active_admin']."'");
			}elseif(isset($_SESSION['active_employee'])){
				$result = mysqli_query($db_con,"SELECT * FROM employees WHERE username='".$_SESSION['active_employee']."'");
			}
			while($row = mysqli_fetch_array($result)){
				echo"<table>
					<tr>
						<td>Username: </td>
						<td><b>".$row['names']." <b></td>
					</tr>
					
					<tr>
						<td>Address: </td>
						<td><b>".$row['district']."</b></td>
					</tr>
					
					<tr>
						<td>Phone number: </td>
						<td><b>".$row['phone']."</b></td>
					</tr>
					<tr>
						<td>Joined on: </td>
						<td><b>".$row['joinedon']."</b></td>
					</tr>
				</table>";
			}
			?>

		</div>
	</div>

<?php
if(isset($_GET['update_cont'])){
	$result_up = mysqli_query($db_con,"SELECT * FROM contracts WHERE id='".$_GET['update_cont']."'");
	$row_up_count = mysqli_num_rows($result_up);
	$row_up = mysqli_fetch_array($result_up);
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='contracts.php'>&times;</a></div>Update contract</div>
				<div class='updateboxform'>";
				if($row_up > 0){
					echo"<form method='POST' action='server.php'>
					<input type='text' name='product' placeholder='Product to be supplied' required value='".$row_up['product']."'><br>
					Starting date:<br>
					<input type='date' name='stdate' required value='".$row_up['starting_date']."'><br>
					Ending date:<br>
					<input type='date' name='endate' required value='".$row_up['ending_date']."'><br>
					<input readonly style='background: #ddd; cursor: not-allowed;' type='text' placeholder='Contarctor' required value='";
						if($row_up['supplier'] != ""){
						echo $row_up['supplier'];
						}else{
							echo $row_up['distributor'];
						}
					echo"'><br>
					<input type='hidden' name='id'  value='".$_GET['update_cont']."'>
					<input type='submit' name='updatecont' value='Save changes'>
				</form>";
				}
			echo"</div>
		</div>
	</div>";
}
?>
</body>
</html>