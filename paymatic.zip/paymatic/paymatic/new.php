<!DOCTYPE html>
<html>
<head>
	<title>New entries</title>
</head>
<body>
<?php
	include('header.php');
	include('new_cont.php');
?>
</body>
</html>