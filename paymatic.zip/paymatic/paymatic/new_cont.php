<!DOCTYPE html>
<html>
<head>
	<script type="text/javascript">
        function num_validation(e) {
            var k = e.keyCode;
            return (k == 8   || (k >= 48 && k <= 57));

        }
    </script>
	<title></title>
	<style type="text/css">
         .failed{
			color: #bb0000;
			margin-bottom: 20px;
			font-weight: bold;
		}
		.close{
			float: right;
			color: white;
		}
		.close a{
			color: white;
			background: #c00;
			padding: 0px 5px;
			border-radius: 50%;
			position: relative;
			left: 20px;
		}
		.content{
			background: white;
			width: 500px;
			padding: 10px;
			box-shadow: 0px 0px 10px 3px gray;
			position: fixed;
			top: 90px;
			left: 220px;
			height: 105%;
			width: 80%;
		}
		.content .newbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 330px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .newbox .newboxform{
			width: 350px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
		}
		.content .newbox .newboxform form input[type='text'],
		.content .newbox .newboxform form select,
		.content .newbox .newboxform form input[type='password']{
			padding: 10px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 20px;
		}
		.content .newbox .newboxform form select{
			width: 260px;
		}
		.content .newbox .newboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .newbox .newboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .contract .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 330px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .contract .contcont{
			width: 350px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
		}
		.content .addbox{
			position: fixed;
			right: 300px;
			top: 145px;
		}
		.content .addbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 330px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .addbox .addboxform{
			width: 350px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
		}
		.content .addbox .addboxform form input[type='text']{
			padding: 10px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 20px;
		}
		.content .addbox .addboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .addbox .addboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
	</style>
</head>
<body>
<div class="content">
	<h2 style="color: #333;">MUKAMIRA ::  New entries</h2><br>
	<div class="newbox">
		<div class="header">Look for a supplier</div>
		<div class="newboxform">
			<?php
			$permit = "readonly style='background: #ccc;cursor: not-allowed;'";
			$names = "";
			$address = "";
			$phone = "";
			$product = "";
			$key = "";
			if(isset($_GET['key'])){
				if($_GET['transaction'] == 'Supply'){
					$result = mysqli_query($db_con,"SELECT * FROM suppliers WHERE id_card='".$_GET['key']."'");
					$row = mysqli_fetch_array($result);
					$key = $_GET['key'];
					$names = $row['f_name']." ".$row['l_name'];
					$address = $row['district']." - ".$row['sector'];
					$phone = $row['phone'];

					$count = mysqli_num_rows($result);
					if($count == 0){
						echo"<p class='failed'>Supplier whose ID card is <span>".$_GET['key']."</span> is not found in the list.</p>";
					}
				}
				else{
					$result = mysqli_query($db_con,"SELECT * FROM distributors WHERE id_card='".$_GET['key']."'");
					$row = mysqli_fetch_array($result);
					$key = $_GET['key'];
					$names = $row['f_name']." ".$row['l_name'];
					$address = $row['district']." - ".$row['sector'];
					$phone = $row['phone'];

					$count = mysqli_num_rows($result);
					if($count == 0){
						echo"<p class='failed'>Distributor whose ID card is <span>".$_GET['key']."</span> is not found in the list.</p>";
					}
				}
			}
			echo"<form method='GET'>
				<select name='transaction'>
					<option>Supply</option>
					<option>Distribution</option>
				</select>	
				<input type='text' name='key' minlength='16' maxlength='16' placeholder='National ID card' required onkeypress='return num_validation(event)' value='".$key."'><input style='padding: 10px 20px;' type='submit' value='Check'><br>
			</form>
			<form method='POST'>
			<input type='text' name='names' placeholder='Full names' required='' ".$permit." value='".$names."'><br>
				<input type='text' name='address' placeholder='Addres: District-Sector' required='' ".$permit." value='".$address."'><br>
				<input type='text' name='phone' placeholder='Phone number' required='' ".$permit." value='".$phone."'><br>
			</form>";
			?>
		</div>
	</div>
	<br><br>
	<div class="contract">
		<div class="header">Contract check</div>
		<div class="contcont">
			<?php
				if(isset($_GET['key'])){
					if($count == 0){
						echo"<p class='failed'>Error.....</p>";
					}
					else{
						if($_GET['transaction'] == 'Supply'){
							$today = date('Y-m-d');
							$result_cont = mysqli_query($db_con,"SELECT * FROM contracts WHERE supplier='".$_GET['key']."' AND ending_date >= '".$today."' ORDER BY id DESC");
							$row_cont = mysqli_fetch_array($result_cont);
							$count_cont = mysqli_num_rows($result_cont);
							if($count_cont == 0){
								echo"<p class='failed'>No active contract found for supplier whose ID card is <span>$key</span></p>";
							}
							else{
								echo"$names has a contract of supplying <b>".$row_cont['product']."</b> However it will end on <b>".$row_cont['ending_date']."</b>";
								$product = $row_cont['product'];
							}
						}
						else{
							$today = date('Y-m-d');
							$result_cont = mysqli_query($db_con,"SELECT * FROM contracts WHERE distributor='".$_GET['key']."' AND ending_date >= '".$today."' ORDER BY id DESC");
							$row_cont = mysqli_fetch_array($result_cont);
							$count_cont = mysqli_num_rows($result_cont);
							if($count_cont == 0){
								echo"<p class='failed'>No active contract found for distributor whose ID card is <span>$key</span></p>";
							}
							else{
								echo"$names has a contract of distributing <b>".$row_cont['product']."</b> However it will end on <b>".$row_cont['ending_date']."</b>";
								$product = $row_cont['product'];
							}
						}
					}
				}
				else{
					echo"<p class='failed'>Waiting.....</p>";
				}
			?>
		</div>
	</div>
	<?php
	$permitadd = "readonly style='background: #ccc;cursor: not-allowed;'";
	$display = "none;";
	$transaction = $_GET['transaction'];
	if(isset($_GET['key'])){
		if($count != 0 AND $count_cont != 0){
			$permitadd = "";
			$display = "block;";
		}
	}
	echo"<div class='addbox'>
		<div class='header'>Record a new supply entry</div>
		<div class='addboxform'>
			<form method='POST' action='server.php'>
			Product:<br>
			<input type='text' name='product' placeholder='Product' value='".$product."' readonly style='background: #ccc;cursor: not-allowed;'><br>
			Quantity:<br>
				<input type='text' name='qty' placeholder='Quantity' required='' ".$permitadd." onkeypress='return num_validation(event)'><br>
				Price:<br>
				<input type='text' name='price' placeholder='Unity price' required='' ".$permitadd." onkeypress='return num_validation(event)'><br>
				<input type='hidden' name='supplier' value='".$key."'>
				<input type='hidden' name='transaction' value='".$transaction."'>
				<input type='submit' name='addnewent' value='Add new' style='display: ".$display."'>
			</form>                                       
		</div>
	</div>";
	?>
</div>
</body>
</html>