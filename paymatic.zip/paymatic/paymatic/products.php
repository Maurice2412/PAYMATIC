<!DOCTYPE html>
<html>
<head>
	<title>Products</title>
</head>
<body>
<?php
	include('header.php');
	include('products_cont.php');
?>
</body>
</html>