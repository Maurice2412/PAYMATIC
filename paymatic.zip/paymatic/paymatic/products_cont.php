<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.close{
			float: right;
			color: white;
		}
		.close a{
			color: white;
			background: #c00;
			padding: 0px 5px;
			border-radius: 50%;
			position: relative;
			left: 20px;
		}
		.content{
			background: white;
			width: 500px;
			padding: 10px;
			box-shadow: 0px 0px 10px 3px gray;
			position: fixed;
			top: 90px;
			left: 220px;
			height: 105%;
			width: 80%;
		}
		.content .newbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 250px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .newbox .newboxform{
			width: 270px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
		}
		.content .newbox .newboxform form input[type='text'],
		.content .newbox .newboxform form input[type='password']{
			padding: 10px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 15px;
		}
		.content .newbox .newboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .newbox .newboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .allbox .header{
			width: 700px;
		}
		.content .allbox .header form{
			float: right;
			margin-top: 
		}
		.content .allbox .header form input[type='text']{
			padding: 6px 20px;
			border: 1px solid #999;
			width: 150px;
			margin-bottom: 20px;
		}
		.content .allbox .header form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.content .allbox .header form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.content .allbox{
			float: left;
			max-width: 770px;
		}
		.content .allbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 65px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .allbox .all{;
			padding: 5px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			padding-bottom: 10px;
			border-top: none;
			width: 820px;
			overflow: scroll;
			position: relative;
			top: -17px;
			height: 510px;
		}
		.content .allbox .all table{
			width: 100%;
		}
		.content .allbox .all table tr .tdheader{
			background: #ff9900;
			color: white;
			padding: 7px 30px;
			font-size: 15px;
		}
		.content .allbox .all table tr td{
			background: #ccc;
			color: #555;
			padding: 5px 10px;
			font-size: 14px;
		}
		.content .allbox .all table tr td img{
			width: 15px;
			height: 15px;
			color: #0099ff;
		}
		.content .allbox .all table tr td a{
			color: #0099ff;
		}
		.content .allbox .all table tr td a:hover{
			text-decoration: underline;
		}
		.update_model{
			position: fixed;
			width: 100%;
			height: 100%;
			background: rgba(0,0,0,.8);
		}
		.update_model .updatebox{
			box-shadow: 0px 0px 10px 5px black;
			position: absolute;
			left: 50%;
			transform: translate(-50%);
			top: 60px;
			border-radius: 10px;
		}
		.update_model .updatebox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 250px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.update_model .updatebox .updateboxform{
			width: 270px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
			background: #fff;
		}
		.update_model .updatebox .updateboxform form input[type='text'],
		.update_model .updatebox .updateboxform form input[type='password']{
			padding: 8px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 15px;
		}
		.update_model .updatebox .updateboxform form input[type='date']{
			padding: 8px 20px;
			border: 1px solid #999;
			width: 220px;
			margin-bottom: 15px;
		}
		.update_model .updatebox .updateboxform  form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		.update_model .updatebox .updateboxform  form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		.update_model .updatebox span{
			font-weight: bold;
			color: #c00;
		}
	</style>
</head>
<body>
<div class="content">
	<h2 style="color: #333;">PAYMATIC ::  Expired Certificates</h2><br>
	<div class="allbox">
		<div class="header">
		<form>
		  <i><input type="text" id="myInput" onkeyup="myFunction()"  placeholder="Search by plate.."  title="Type in a name"> </i>
		</form>
		All Expired Certificates</div>
		<div class="all">
			<table id="myTable">
				<tr>
					<td class="tdheader">Plate Number</td>
					<td class="tdheader">Owner</td>
					<td class="tdheader">Phone</td>
					<td class="tdheader">Date Fitted</td>
					<td class="tdheader">Expiry Date</td>
					<td class="tdheader" colspan="3">Options</td>
				</tr>
				<?php
				$today = date('Y-m-d');
				$result = mysqli_query($db_con,"SELECT * FROM certificates where endingdate <'$today' ");
				while($row = mysqli_fetch_array($result)){
					echo"<tr>
					<td>".$row['plate']."</td>
					<td>".$row['owner']."</td>
					<td>".$row['telephone']."</td>
					<td>".$row['startdate']."</td>
					<td>".$row['endingdate']."</td>
					<td><img src='images/edit.png'>
						<a  href='send.php?sendsms=".$row['plate']."&&date=".$row['endingdate']."&&phone=".$row['telephone']."' >Resend SMS</a>
					</td>
					<td><img src='images/edit.png'>
						<a  href='?update_cont=".$row['plate']."' >Update</a>
						
					</td>
					<td><img src='images/edit.png'>
						<a href='server.php?delete_cont1=".$row['plate']."'>Delete</a>
					</td>
				</tr>" ; 
				
				
			
			
			
	     


}



	?>
		
			</table> <hr>	<br>	
		</div>
	</div>
  <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

<?php
if(isset($_GET['update_cont'])){
	$result_up = mysqli_query($db_con,"SELECT * FROM certificates WHERE plate='".$_GET['update_cont']."'");
	$row_up_count = mysqli_num_rows($result_up);
	$row_up = mysqli_fetch_array($result_up);
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='products.php'>&times;</a></div>Update Certificate</div>
				<div class='updateboxform'>";
				if($row_up > 0){
					echo"<form method='POST' action='server.php'>
					<input type='text' name='owner' placeholder='' required value='".$row_up['owner']."'><br>
					<input type='text' name='telephone' placeholder='' required value='".$row_up['telephone']."'><br>
					<input type='text' style='background: #ddd; cursor: not-allowed;' readonly name='plate' placeholder='' required value='".$row_up['plate']."'><br>
					<input type='date' name='stdate' placeholder='' required value='".$row_up['startdate']."'><br><br>
					<input type='date' name='endate' placeholder='' required value='".$row_up['endingdate']."'><br>
					
					<input type='submit' name='updatecont' value='Save changes'>
				</form>";
				

		
				
				}
			echo"</div>
		</div>
	</div>";
}
if(isset($_GET['error'])){
	echo"<div class='update_model'>
		<div class='updatebox'>
			<div class='header'><div class='close'><a href='products.php'>&times;</a></div>Duplicate error detected</div>
			<div class='updateboxform'>";
				echo"<p>Another product is registerd with <br><br><span>".$_GET['error']."</span> name.
				<br><br>Change the name and try again.</p>
			
			
			</div>
		</div>
	</div>";
}
?>
</body>
</html>