<!DOCTYPE html>
<html>
<head>
	<title>RECEIPT</title>
	<style type="text/css">
		.rec{
			position: absolute;
			top:50px;
			left: 50%;
			transform: translate(-50%);
			font-family: arial;
			width: 400px;
			border: 1px solid #222;
		}
		.rec .header{
			background: #222;
			padding: 10px;
			text-align: center;
			color: #fff;
			font-weight: bold;
		}
		.rec .content{
			padding: 50px 30px;
		}
		.rec img{
			margin-top: -50px;
		}
		table{
			width: 95%;
		}
		table tr td{
			padding: 5px 10px;
		}
	</style>
</head>
<body>
	<p id="print" onclick="window.print();" style="color: #fff;padding: 10px 20px;border-radius: 5px; float: left; background: #09f;margin: 20px;cursor: pointer; font-family: arial;">Print</p>
	<div class="rec">
		<div class="header">RECEIPT</div>
		<div class="content" style="background: url(images/receipt_back.png);">
			<?php
			include('connection.php');
			if($_GET['type'] == 'supply'){
				$result_list = mysqli_query($db_con,"SELECT * FROM supplies WHERE id='".$_GET['key']."'");
				$row_list = mysqli_fetch_array($result_list);
				$result_sup = mysqli_query($db_con,"SELECT * FROM suppliers WHERE id_card = '".$row_list['supplier']."' ");
			}else{
				$result_list = mysqli_query($db_con,"SELECT * FROM distributions WHERE id='".$_GET['key']."'");
				$row_list = mysqli_fetch_array($result_list);
				$result_sup = mysqli_query($db_con,"SELECT * FROM distributors WHERE id_card = '".$row_list['distributor']."' ");
			}

			$row_sup = mysqli_fetch_array($result_sup);

			$amount = ($row_list['quantity'] * $row_list['price']);
			$vat = ($amount * 18) / 100;
			$total = $amount - $vat;


			echo"<h3 align='center'><img src='images/mukamira.png' width='150'></h3>";
			echo"<p>Supplier name: <b>".$row_sup['f_name']." ".$row_sup['l_name']."</b></p>";
			echo"<p>Supplier ID: <b>".$row_sup['id_card']."</b></p>";
			echo"<p>Date of transaction: <b>".$row_list['t_date']."</b></p>";
			echo"<table border='1' cellspacing='0'>
				<tr>
					<td class='tdheader'>Product</td>
					<td>".$row_list['product']."</td>
				</tr>
				<tr>
					<td class='tdheader'>Quantity</td>
					<td>".$row_list['quantity']."</td>
				</tr>
				<tr>
					<td class='tdheader'>U-P</td>
					<td>".$row_list['price']." Rwf</td>
				</tr>
				<tr>
					<td class='tdheader'>Amount to be paid</td>
					<td>".round($amount, 2)." Rwf</td>
				</tr>
				<tr>
					<td class='tdheader'>VAT(18%)</td>
					<td>".round($vat, 2)." Rwf</td>
				</tr>
				<tr>
					<b><td class='tdheader'>TOTAL</td>
					<td>".round($total, 2)." Rwf</td></b>
				</tr>			
			</table>

			<br><br>
			This is under approval of <b>".$row_list['approval']."</b>
			<br><br><br><br>
			";
			?>
		</div>
	</div>
</body>
</html>