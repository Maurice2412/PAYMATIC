<!DOCTYPE html>
<html>
<head>
	<title>Supplies</title>
</head>
<body>
<?php
	include('header.php');
	include('reports_cont.php');
?>
</body>
</html>