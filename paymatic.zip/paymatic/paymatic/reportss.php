<!DOCTYPE html>
<html>
<head>
	<title>Distributions</title>
</head>
<body>
<?php
	include('header.php');
	include('reportss_cont.php');
?>
</body>
</html>