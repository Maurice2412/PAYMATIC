<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.close{
			float: right;
			color: white;
		}
		.close a{
			color: white;
			background: #c00;
			padding: 0px 5px;
			border-radius: 50%;
			position: relative;
			left: 20px;
		}
		.content{
			background: white;
			width: 500px;
			padding: 10px;
			box-shadow: 0px 0px 10px 3px gray;
			position: fixed;
			top: 90px;
			left: 220px;
			height: 105%;
			width: 80%;
		}
		.content .allbox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.content .allbox .all{;
			padding: 5px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			padding-bottom: 10px;
			border-top: none;
			overflow-y: scroll;
			height: 470px;
		}
		.content .allbox .all table{
			width: 100%;
		}
		.content .allbox .all table tr .tdheader{
			background: #ff9900;
			color: white;
			padding: 5px 15px;
			font-size: 15px;
		}
		.content .allbox .all table tr td{
			background: #ccc;
			color: #555;
			padding: 5px 10px;
			font-size: 13px;
		}
		.content .allbox .all table tr td img{
			width: 15px;
			height: 15px;
			color: #0099ff;
		}
		.content .allbox .all table tr td a{
			color: #0099ff;
		}
		.content .allbox .all table tr td a:hover{
			text-decoration: underline;
		}
		form input[type='submit']{
			border: 1px solid #041f3e;
			background: #041f3e;
			padding: 5px 20px;
			cursor: pointer;
			transition: .2s;
			color: #fff; 
		}
		form input[type='submit']:hover{
			background: #fff;
			color: #041f3e;
		}
		form input[type='date']{
			padding: 5px 10px;
			border: 1px solid #bbb;
			width:120px;
			margin-bottom: 10px;
		}
		.update_model{
			top: 0px;
			left: 0px;
			position: fixed;
			width: 100%;
			height: 100%;
			background: rgba(0,0,0,.8);
		}
		.update_model .updatebox{
			box-shadow: 0px 0px 10px 5px black;
			position: absolute;
			left: 50%;
			transform: translate(-50%);
			top: 160px;
			border-radius: 10px;
		}
		.update_model .updatebox .header{
			font-size: 20px;
			background: linear-gradient(#ddd,#fff);
			padding: 10px 30px;
			width: 300px;
			border-radius: 10px 10px 0px 0px;
			border: 1px solid #bbb;
			color: #555;
		}
		.update_model .updatebox .updateboxform{
			width: 320px;
			border-radius: 0px 0px 10px 10px;
			border: 1px solid #bbb;
			border-top: none;
			padding: 20px;
			background: #fff;
		}
	</style>
</head>
<body>
<div class="content">
	<form method="GET" style="float: right;">
		<label>Report by date || From:</label>
		<input type="date" name="from" required="">
		<label>Up to:</label>
		<input type="date" name="up_to" required="">
		<input type="submit" value="Generate">
	</form>
	<h2 style="color: #333;">MUKAMIRA ::  Reports</h2><br>
	<div class="allbox">
		<div class="header">
		<form style='float: right;' method="GET" action="exportall_dis.php">
			<input style="padding: 5px 20px;position: relative; top: -3px; left: 20px; border-radius: 30px;" type="submit" name="export" value="Export">
		</form>
		All registered distributions</div>
		<div class="all">
			<table>
				<?php
				$result = mysqli_query($db_con,"SELECT DISTINCT(product) FROM distributions ORDER BY id DESC");
				while($row = mysqli_fetch_array($result)){
					$total_q = 0;
					$total_p = 0;
					if(isset($_GET['from'])){
						$result_list = mysqli_query($db_con,"SELECT * FROM distributions WHERE product = '".$row['product']."' AND t_date >= '".$_GET['from']."' AND t_date <= '".$_GET['up_to']."' ORDER BY id DESC");
					}else{
						$result_list = mysqli_query($db_con,"SELECT * FROM distributions WHERE product = '".$row['product']."' ORDER BY id DESC");
					}
					$count_list = mysqli_num_rows($result_list);
					if($count_list > 0){
						$my_list = 0;
						echo"<tr><td colspan='9' style='background: #041f3e; color:#fff; font-weight: bold;'>General report for distribution of ".$row['product']."</td></tr>
						<tr>
							<td class='tdheader'>Product</td>
							<td class='tdheader'>Quantity</td>
							<td class='tdheader'>U-P</td>
							<td class='tdheader'>Total</td>
							<td class='tdheader'>Distributor ID</td>
							<td class='tdheader'>Full names</td>
							<td class='tdheader'>Approved by</td>
							<td class='tdheader'>Date of transaction</td>
							<td class='tdheader'>Receipt</td>
						</tr>";
					}
					while($row_list = mysqli_fetch_array($result_list)){
						$result_sup = mysqli_query($db_con,"SELECT * FROM distributors WHERE id_card = '".$row_list['distributor']."' ");
						$row_sup = mysqli_fetch_array($result_sup);
						$total = ($row_list['quantity'] * $row_list['price'])." Rwf";
						$total_add = ($row_list['quantity'] * $row_list['price']);
						echo"<tr>
						<td>".$row_list['product']."</td>
						<td>".$row_list['quantity']."</td>
						<td>".$row_list['price']." Rwf</td>
						<td>".$total."</td>
						<td>".$row_sup['id_card']."</td>
						<td>".$row_sup['f_name']." ".$row_sup['l_name']."</td>
						<td>".$row_list['approval']."</td>
						<td>".$row_list['t_date']."</td>
						<td><a target='_blank' href='receipt.php?key=".$row_list['id']."&type=distribution'>Print</a></td>
						</tr>";
						$total_q += $row_list['quantity'];
						$total_p += $total_add;
					}
					if($count_list > 0){
						echo"<tr>
							<td style='font-size: 16px; background: #fff;text-align: right;' colspan='8'>Total quantity: $total_q</td>
						</tr>
						<tr>
							<td style='font-size: 16px; background: #fff;text-align: right;' colspan='8'>Total amount: $total_p Rwf</td>
						</tr>";
						$my_list = 1;
					}
				}
				if($my_list == 0){
					echo"<div class='update_model'>
						<div class='updatebox'>
							<div class='header'><div class='close'><a href='home.php'>&times;</a></div>Records error detected</div>	
							<div class='updateboxform'>
								No records found corresponding the search.
							</div>
						</div>
					</div>";
				}
				?>
			</table>
		</div>
	</div>
</div>
</body>
</html>