<?php session_start();
$to=$_POST["strMobile"];
$msg=$_POST["commentaire"]; 	
$from='PAYMATIC';
header('Location:http://rslr.connectbind.com:8080/bulksms/bulksms?username=clr-paymaticltd&password=Pay2020&type=0&dlr=1&destination='.$to.'&source='.$from.'&message='.$msg.'');
?>