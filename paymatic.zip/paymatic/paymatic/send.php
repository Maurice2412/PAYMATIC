<?php 

$plot = $_REQUEST['sendsms'];
$phone =  $_REQUEST['phone'];
$to=$phone;
$msg="Muraho neza,Turabamenyesha ko certificate y'imodoka yanyu ".$plot." yarangiye.Murasabwa kwihutira kongeresha igihe. Hamagara 0788730014, 0788444316,0788242412";
$from='PAYMATIC';
header('Location:http://rslr.connectbind.com:8080/bulksms/bulksms?username=clr-paymaticltd&password=Pay2020&type=0&dlr=1&destination='.$to.'&source='.$from.'&message='.$msg.'');	

echo '<script>window.location="products.php"</script>';
?>