<?php     
class Sender{
var $host;
var $port;
/*
*Username that is to be used for submission
*/
var $strUserName;
/*
*Password that is to be used along with username
*/
var $strPassword;
/*
*Sender Id to be used for submitting the message
*/
var $strSender;
/*
*Message content that is to be transmitted
*/
var $strMessage;
/*
*Mobile No is to be transmitted
*/
var $strMobile;
/*
*What type of message that is to be sent
*<ul>
*<li>0:means plain text</li>
*<li>1:means flash</li>
*<li>2:means unicode (Message content should be in Hex)</li>
*<li>6:means unicode flash (Message content should be in Hex)</li>
*</ul>
*/
var $strMessageType;
/*
*Require DLR or not
*<ul>
*<li>0:means DLR is not required</li>
*<li>1:means DLR is required</li>
*</ul>
*/
var $strDlr;
private function sms_unicode($message){
$hex1='';
if (function_exists(iconv)){
$latin=@iconv('UTF-8','ISO-8859-1',$message);
if (strcmp($latin, $message)){
$arr=unpack('H*hex', @iconv('UTF-8','UCS-2BE',$message));
$hex1=strtouper($arr['hex']);
}
if($hex1==''){
$hex2='';
$hex='';
for ($i=0;$i<strlen($message);$i++){
$hex=dechex(ord($message[$i]));
$len=strlen($hex);
$add=4-$len;
if($len<4){
for ($j=0;$j<$add;$j++){
$hex="0".$hex;
}
}
$hex2.=$hex;
}
return $hex2;
}
else{
return $hex1;
}
}
else{
print 'iconv Function Not Exists';
}
}


    
//Constructor...
public function Sender($host, $port, $username, $password, $sender, $message, $mobile, $msgtype, $dlr){
$this->host=$host;
$this->port=$port;
$this->strUserName=$username;
$this->strPassword=$password;
$this->strSender=$sender;
$this->strMessage=$message;//URL Encode The Message...
$this->strMobile=$mobile;
$this->strMessageType=$msgtype;
$this->strDlr=$dlr;
}
public function Submit(){
if($this->strMessageTypet="2"||$this->strMessageTypet="6"){
//Call the Function Of String To HEX.
$this->strMessage=$this->sms_unicode($this->strMessage);
try{
//Smpp http Url to send sms.
$live_url="http://".$this->host.":".$this->port."/bulksms/bulksms?username=".$this->strUserName."&password=".$this->strPassword."&type=".$this->strMessageType."&dlr=".$this->strDlr."&destination=".$this->strMobile."&source=".$this->strSender."&message=".$this->strMessage."";
$parse_url=file($live_url);
echo $parse_url[0];
}
catch(Exception $e){
echo 'Message:'.$e->getMessage();
}
}
else
$this->strMessage=urlencode($this->strMessage);

try{
//Smpp http Url to send sms.
$live_url="http://".$this->host.":".$this->port."/bulksms/bulksms?username=".$this->strUserName."&password".$this->strPassword."&type=".$this->strMessageType."&dlr=".$this->strDlr."&destination=".$this->strMobile."&source=".$this->strSender."&message=".$this->strMessage."";
$parse_url=file($live_url);
echo $parse_url[0];
}
catch(Exception $e){
echo 'Message:'.$e->getMessage();
}
}
}

//Call The Construction.
/*$obj=new Sender('smsplus3.routesms.com','8080','nduwawe','frt56hg',$_POST["strSender"],$_POST["strMessage"],$_POST["strMobile"],'0','1');*/
$obj=new Sender('rslr.connectbind.com','8080','clr-paymaticltd','Pay2020','PAYMATIC',$_POST["commentaire"]." ",$_POST["strMobile"],'2','1');
$obj->Submit();

echo $sender;

header("Location: send_sms_api_form.php");

?>