<html>

<head>

</head> 
   
<body> 
  <form action="sample1.php" method="post" name="sendsms" onsubmit="return validateForm()">
  <table>
  <tr>
  <td>Sender:</td>
  <td><input type="text" name="strSender" value="" /></td>
  </tr>
  <tr>
  <td>Recipient</td>
  <td><input type="text" name="strMobile" maxlength="12" value='.$row["phone"].'><br>(Ex: 250784251104)</td>
  </tr>
  <tr>
  <td>Message:</td>
  <td><textarea id="commentaire" name="commentaire" class="limiter" cols="20" rows="4" maxlength="140">Hello! You are registered on Medo Network Marketing. Your Username: '.$_POST['add'].' and Password: '.$new_pass.'. Thank you!</textarea></td>
  </tr>
  <tr>
  <td></td>
        <td>
    <input type="submit" value="Send SMS" name="submit" />
    </td>
  </tr>
  </table>
  </form> 
</body> 
</html>