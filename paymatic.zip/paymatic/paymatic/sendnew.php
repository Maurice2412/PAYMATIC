<?php
include('connection.php');

if (isset($_POST['newcont'])) {
	$plate = $_POST['plate'];
	$stdate = $_POST['stdate'];
	$endate = $_POST['endate'];
	$owner = $_POST['owner'];
	$telephone = $_POST['telephone'];
	//CHECKING DATES
	if(($stdate < date('Y-m-d')) OR ($endate < date('Y-m-d'))){
		header("location: contracts.php?date_error=ERROR");
	}elseif($stdate > $endate){
		header("location: contracts.php?date_error=ERROR");
	}else{
		mysqli_query($db_con,"INSERT INTO certificates VALUES('$plate','$owner','$telephone','$stdate','$endate','0')");
	    
$to=$telephone;
$msg="Mukiliya ufite imodoka ".$plate." certificate yanyu ifite agaciro Kuva ".$stdate." Kugera ".$endate." Murakoze.";
$from='PAYMATIC';
header('Location:http://rslr.connectbind.com:8080/bulksms/bulksms?username=clr-paymaticltd&password=Pay2020&type=0&dlr=1&destination='.$to.'&source='.$from.'&message='.$msg.'');


echo '<script>window.location="contracts.php"</script>';
}}
?>