<?php     


header("Location: contracts.php");

?>
<?php
session_start();
include('connection.php');
if (isset($_POST['addnew']) OR isset($_POST['update'])) {
	$idcard = $_POST['idcard'];
	$names = $_POST['names'];
	$district = $_POST['district'];
	$sector = $_POST['sector'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$joined = date('d, M Y');

	$phone = $_POST['phone'];
	$c_code = $_POST['c_code'];
	$phone = $c_code.$phone;	

	if(isset($_POST['addnew'])){
		$check = mysqli_query($db_con,"SELECT * FROM suppliers WHERE id_card='".$idcard."'");
		$row_check = mysqli_fetch_array($check);
		$countc = mysqli_num_rows($check);
		if($countc > 0){
			header("location: suppliers.php?error=".$idcard."&names=".$row_check['names']."");
		}
		else{
			mysqli_query($db_con,"INSERT INTO suppliers VALUES('$idcard','$names','$district','$sector','$phone','$username','$password','$joined')");
			header('location: suppliers.php');
		}
	}
	elseif(isset($_POST['update'])){
		$supplier = $_POST['supplier'];
		mysqli_query($db_con,"UPDATE suppliers SET names='$names', district='$district', sector='$sector', phone='$phone', username='$username', password ='$password' WHERE id_card='$supplier'");
		header('location: suppliers.php');
	}
}

if (isset($_POST['addnewdis']) OR isset($_POST['updatedis'])) {
	$idcard = $_POST['idcard'];
	$names = $_POST['names'];
	$district = $_POST['district'];
	$sector = $_POST['sector'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$joined = date('d, M Y');

	$phone = $_POST['phone'];
	$c_code = $_POST['c_code'];
	$phone = $c_code.$phone;

	if(isset($_POST['addnewdis'])){
		$check = mysqli_query($db_con,"SELECT * FROM distributors WHERE id_card='".$idcard."'");
		$row_check = mysqli_fetch_array($check);
		$countc = mysqli_num_rows($check);
		if($countc > 0){
			echo"qwerty";
			header("location: distributors.php?error=".$idcard."&names=".$row_check['names']."");
		}
		else{
			mysqli_query($db_con,"INSERT INTO distributors VALUES('$idcard','$names','$district','$sector','$phone','$username','$password','$joined')");
			header('location: distributors.php');
		}
	}
	elseif(isset($_POST['updatedis'])){
		$distributor = $_POST['distributor'];
		mysqli_query($db_con,"UPDATE distributors SET names='$names', district='$district', sector='$sector', phone='$phone', username='$username', password ='$password' WHERE id_card='$distributor'");
		header('location: distributors.php');
	}
}

if (isset($_POST['addnewcont'])) {
	$product = $_POST['product'];
	$stdate = $_POST['stdate'];
	$endate = $_POST['endate'];
	$contractor = $_POST['contractor'];

	$cont_type = $_POST['cont_type'];
	$countc1 = 0;
	$countc2 = 0;

	//CHECKING DATES
	if(($stdate < date('Y-m-d')) OR ($endate < date('Y-m-d'))){
		header("location: contracts.php?date_error=ERROR");
	}elseif($stdate > $endate){
		header("location: contracts.php?date_error=ERROR");
	}else{

		if($cont_type == 'Supply contract'){
			$supplier = $contractor;
			$distributor = "";
			$check1 = mysqli_query($db_con,"SELECT * FROM suppliers WHERE id_card='".$contractor."'");
			$countc1 = mysqli_num_rows($check1);
		}
		else{
			$distributor = $contractor;
			$supplier = "";
			$check2 = mysqli_query($db_con,"SELECT * FROM distributors WHERE id_card='".$contractor."'");
			$countc2 = mysqli_num_rows($check2);
		}

		if(isset($_SESSION['active_admin'])){
			$approval = $_SESSION['active_admin'];
		}
		else{
			$approval = $_SESSION['active_employee'];
		}

		if($cont_type == 'Supply contract'){
			if($countc1 == 0){
				header("location: contracts.php?sup_error=".$contractor."");
			}
			else{
				mysqli_query($db_con,"INSERT INTO contracts VALUES(null,'$product','$stdate','$endate','$supplier','$distributor','$approval')");
				header('location: contracts.php');
			}
		}
		else{
			if($countc2 == 0){
				header("location: contracts.php?dis_error=".$contractor."");
			}
			else{
				mysqli_query($db_con,"INSERT INTO contracts VALUES(null,'$product','$stdate','$endate','$supplier','$distributor','$approval')");
				header('location: contracts.php');
			}
		}
	}
	//END OF CHECKING DATES
}


if (isset($_POST['addnewent'])) {
	$product = $_POST['product'];
	$qty = $_POST['qty'];
	$price = $_POST['price'];
	$supplier = $_POST['supplier'];
	$transaction = $_POST['transaction'];

	if(isset($_SESSION['active_admin'])){
		$approval = $_SESSION['active_admin'];
	}
	else{
		$approval = $_SESSION['active_employee'];
	}
	$t_date = date('Y-m-d');

	if($transaction == 'Supply'){
		mysqli_query($db_con,"INSERT INTO supplies VALUES(null,'$product','$qty','$price','$supplier','$approval','$t_date','0')");

		//Updating stock
		$result_stock = mysqli_query($db_con,"SELECT * FROM products WHERE name='$product'");
		$row_stock = mysqli_fetch_array($result_stock);
		$current_stock = $row_stock['stock'];
		$new_stock = $current_stock + $qty;
		mysqli_query($db_con,"UPDATE products SET stock = '$new_stock' WHERE name = '$product'");
	}else{
		mysqli_query($db_con,"INSERT INTO distributions VALUES(null,'$product','$qty','$price','$supplier','$approval','$t_date','0')");

		//Updating stock
		$result_stock = mysqli_query($db_con,"SELECT * FROM products WHERE name='$product'");
		$row_stock = mysqli_fetch_array($result_stock);
		$current_stock = $row_stock['stock'];
		$new_stock = $current_stock - $qty;
		mysqli_query($db_con,"UPDATE products SET stock = '$new_stock' WHERE name = '$product'");
	}
	header('location: new.php');
}

if (isset($_POST['addnewemp']) OR isset($_POST['updatemp'])) {
	$idcard = $_POST['idcard'];
	$names = $_POST['names'];
	$address = $_POST['address'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	
    //$password = password_hash($password,PASSWORD_DEFAULT);
    
	$joined = date('d, M Y');

	$phone = $_POST['phone'];
	$c_code = $_POST['c_code'];
	$phone = $c_code.$phone;

	if(isset($_POST['addnewemp'])){
		$check = mysqli_query($db_con,"SELECT * FROM employees WHERE id_card='".$idcard."'");
		$row_check = mysqli_fetch_array($check);
		$countc = mysqli_num_rows($check);
		if($countc > 0){
			echo"qwerty";
			header("location: employee.php?error=".$idcard."&names=".$row_check['names']."");
		}
		else{
			$me = mysqli_query($db_con,"INSERT INTO employees(id_card,names,address,phone,username,password,joinedon) VALUES('$idcard','$names','$address','$phone','$username','$password','$joined')");
			echo $me;
			header('location: employee.php');
		}
	}
	elseif(isset($_POST['updatemp'])){
		$employee = $_POST['employee'];
		mysqli_query($db_con,"UPDATE employees SET names='$names', address='$address', phone='$phone', username='$username', password ='$password' WHERE id_card='$employee'");
		header('location: employee.php');
	}
}

if (isset($_POST['addnewpro']) OR isset($_POST['updatepro'])) {
	$pro_name = $_POST['pro_name'];
	$price = $_POST['price'];

	if(isset($_POST['addnewpro'])){
		$check = mysqli_query($db_con,"SELECT * FROM products WHERE name='".$pro_name."'");
		$row_check = mysqli_fetch_array($check);
		$countc = mysqli_num_rows($check);
		if($countc > 0){
			echo"qwerty";
			header("location: products.php?error=".$pro_name."");
		}
		else{
			$me = mysqli_query($db_con,"INSERT INTO products(name,price) VALUES('$pro_name','$price')");
			echo $me;
			header('location: products.php');
		}
	}
	elseif(isset($_POST['updatepro'])){
		$product = $_POST['product'];
		mysqli_query($db_con,"UPDATE products SET name='$pro_name', price='$price' WHERE id='$product'");
		header('location: contracts.php');
	}
}


//Deletion of data

//employees
if(isset($_GET['delete_emp'])){
	$key = $_GET['delete_emp'];
	mysqli_query($db_con,"DELETE FROM employees WHERE id_card='$key'");
	header('location: employee.php');
}
//certificate
if(isset($_GET['delete_cont'])){
	$key = $_GET['delete_cont'];
	mysqli_query($db_con,"DELETE FROM certificates WHERE plate='$key'");
	
	header('location: contracts.php');
}
//certificate deletion from expired
if(isset($_GET['delete_cont1'])){
	$key = $_GET['delete_cont1'];
	mysqli_query($db_con,"DELETE FROM certificates WHERE plate='$key'");
	
	header('location: products.php');
}
?>