<!DOCTYPE html>
<html>
<head>
	<title>Suppliers</title>
</head>
<body>
<?php
	include('header.php');
	include('suppliers_cont.php');
?>
</body>
</html>